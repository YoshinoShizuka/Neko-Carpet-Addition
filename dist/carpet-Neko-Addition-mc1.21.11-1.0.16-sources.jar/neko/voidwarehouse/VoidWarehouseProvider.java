package neko.voidwarehouse;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_3908;

/**
 * 给 {@code ServerPlayer#openMenu(MenuProvider)} 用的菜单工厂。
 *
 * <p><b>标题为什么用字面量而不是翻译键：</b>方案 A 允许纯原版客户端进入，
 * 而原版客户端没有我们的语言文件，翻译键会被原样显示成
 * {@code container.carpet_neko_addition.void_warehouse}。所以标题必须由服务端直接给出成品文本。</p>
 *
 * <p>页码是每个玩家各自的状态，不在这里决定：这里只把共享数据交给新的
 * {@link VoidWarehouseMenu}，由它自己新建一个从第 1 页开始的页面视图。</p>
 */
public record VoidWarehouseProvider(VoidWarehouseData data) implements class_3908 {
    /** 界面标题，同时也是触发用的物品名 */
    public static final String TITLE_TEXT = "虚空仓库";

    private static final class_2561 TITLE = class_2561.method_43470(TITLE_TEXT);

    @Override
    public class_2561 method_5476() {
        return TITLE;
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new VoidWarehouseMenu(syncId, playerInventory, this.data, player);
    }
}
