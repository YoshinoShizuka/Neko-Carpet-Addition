package neko.voidwarehouse;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2480;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

/**
 * 「潜影盒打包 / 拆解」的全部规则，集中在这一个类里。
 *
 * <h2>为什么要这么做</h2>
 * <p>仓库的模型是「一种物品 = 一格，数量无上限」。潜影盒恰好是原版里唯一能让玩家
 * <b>自己决定一格装多少</b>的容器，所以把它当作仓库的「打包单位」最自然：
 * 存的时候把盒子拆成原料，取的时候再按原料现造一个盒子。
 * 这样仓库里永远只有「纯净的散件」，不会有成千上万个「装着不同东西的潜影盒」把格子撑爆。</p>
 *
 * <h2>换算规则（原版配方）</h2>
 * <pre>
 *   1 个潜影盒 = 2 个潜影壳 + 1 个箱子
 *   1 个染色潜影盒 = 2 个潜影壳 + 1 个箱子 + 1 个对应颜色的染料
 *   1 盒能装 = 27 格 × 该物品的堆叠上限
 *              （圆石这类 64 → 1728；末影珍珠这类 16 → 432；床这类 1 → 27）
 * </pre>
 * <p>所以「取出 1 个装满圆石的潜影盒」= 扣 1728 个圆石 + 2 个潜影壳 + 1 个箱子；
 * 「存入 1 个装着 3 种东西的潜影盒」= 加那 3 种物品各自的真实数量 + 2 个潜影壳 + 1 个箱子。
 * 两个方向都严格守恒，不多不少。</p>
 *
 * <p><b>染色盒的染料也要还</b>：原版里染色盒是「任意潜影盒 + 1 个对应染料」合成的，
 * 所以拆一个染色盒必须吐出 {@code 2 壳 + 1 箱 + 1 染料} —— 只还壳和箱等于把玩家那个
 * 染料吞了。见 {@link #dyeOf(class_1799)}。</p>
 *
 * <h2>识别</h2>
 * <p>26.3 里没有 {@code ShulkerBoxItem} 这个类，潜影盒是 <b>普通 {@code BlockItem}</b>
 * （方块是 {@link class_2480}），所以用「物品是 BlockItem 且它的方块是潜影盒」
 * 来识别 —— 这样<b>带颜色的潜影盒也一并认出来</b>，不需要枚举 16 种颜色。</p>
 */
public final class VoidWarehouseShulker {
    /** 一个潜影盒的容纳格数（原版固定 27 格） */
    public static final int BOX_SLOTS = 27;

    /** 合成 1 个潜影盒需要的潜影壳数量（原版配方） */
    public static final int SHELL_COST = 2;

    /** 合成 1 个潜影盒需要的箱子数量（原版配方） */
    public static final int CHEST_COST = 1;

    /** 合成 1 个<i>染色</i>潜影盒需要的染料数量（原版配方：染色盒 = 潜影盒 + 1 染料） */
    public static final int DYE_COST = 1;

    private VoidWarehouseShulker() {
    }

    /**
     * 这个堆叠是不是一个潜影盒（任何颜色都算）。
     *
     * <p>26.3 没有 {@code ShulkerBoxItem}，潜影盒就是方块 {@link class_2480} 的
     * {@link class_1747}，所以从方块那一侧反查最省事，也顺手覆盖了 16 种染色盒。</p>
     */
    public static boolean isShulkerBox(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return stack.method_7909() instanceof class_1747 blockItem
                && blockItem.method_7711() instanceof class_2480;
    }

    /**
     * 这个盒子的颜色；<b>无色盒返回 {@code null}</b>。
     *
     * <p>颜色记在<b>方块</b>上（{@link class_2480#method_10528()}），物品只是个
     * {@code BlockItem}，所以要从方块反查。</p>
     */
    public static class_1767 colorOf(class_1799 box) {
        if (box == null || box.method_7960()) {
            return null;
        }
        return box.method_7909() instanceof class_1747 blockItem
                && blockItem.method_7711() instanceof class_2480 shulker
                ? shulker.method_10528() : null;
    }

    /**
     * 拆解这个盒子时应当<b>归还的染料</b>（无色盒返回 {@link class_1799#field_8037}）。
     *
     * <p>原版配方是「任意潜影盒 + 1 个对应染料 → 染色盒」，所以拆染色盒时除了
     * {@code 2 壳 + 1 箱} 还得把那个染料吐回来。少了这一步，玩家每存一次染色盒就
     * 平白少一个染料 —— 而仓库对外承诺的是「拆开 = 逆向合成、严格守恒」。</p>
     *
     * <p>这个版本里 16 种染料还是<b>各自独立的 {@code Items} 字段</b>（{@code Items.RED_DYE}…），
     * 26.2 起才统一收进 {@code ColorCollection}（{@code Items.DYE.pick(color)}），
     * 所以这里枚举一遍。</p>
     */
    public static class_1799 dyeOf(class_1799 box) {
        class_1767 color = colorOf(box);
        return color == null ? class_1799.field_8037 : new class_1799(dyeItem(color), DYE_COST);
    }

    /**
     * 颜色 → 染料物品。
     *
     * <p>{@link class_1767} 的 16 个常量与 {@code Items} 里的 16 个染料字段一一对应，
     * 但字段名是「颜色名 + _DYE」，只能用 {@code switch} 显式列出来 —— 拿枚举名拼字符串
     * 再用反射查字段，拼错了要等运行期才知道，不值得。</p>
     */
    private static class_1792 dyeItem(class_1767 color) {
        return switch (color) {
            case field_7952 -> class_1802.field_8446;
            case field_7946 -> class_1802.field_8492;
            case field_7958 -> class_1802.field_8669;
            case field_7951 -> class_1802.field_8273;
            case field_7947 -> class_1802.field_8192;
            case field_7961 -> class_1802.field_8131;
            case field_7954 -> class_1802.field_8330;
            case field_7944 -> class_1802.field_8298;
            case field_7967 -> class_1802.field_8851;
            case field_7955 -> class_1802.field_8632;
            case field_7945 -> class_1802.field_8296;
            case field_7966 -> class_1802.field_8345;
            case field_7957 -> class_1802.field_8099;
            case field_7942 -> class_1802.field_8408;
            case field_7964 -> class_1802.field_8264;
            case field_7963 -> class_1802.field_8226;
        };
    }

    /** 一盒装满能装多少个「这种物品」 */
    public static int capacity(class_1799 template) {
        return BOX_SLOTS * Math.max(1, template.method_7914());
    }

    /**
     * 读出盒子里所有<b>非空</b>的内容。
     *
     * <p>返回的每一份都是<b>拷贝</b>（{@code nonEmptyItemCopyStream}），
     * 调用方可以放心地清空它们，不会反过来改到盒子本身。</p>
     */
    public static List<class_1799> contentsOf(class_1799 box) {
        if (!isShulkerBox(box)) {
            return List.of();
        }
        class_9288 contents = box.method_58694(class_9334.field_49622);
        if (contents == null) {
            return List.of();
        }
        List<class_1799> out = new ArrayList<>();
        contents.method_59715().forEach(out::add);
        return out;
    }

    /** 空盒子？（盒子里一个东西都没有） */
    public static boolean isEmptyBox(class_1799 box) {
        return isShulkerBox(box) && contentsOf(box).isEmpty();
    }

    /**
     * 把 {@code count} 个 {@code template} 打包成一个潜影盒。
     *
     * <p>从第 0 格开始按「每格装满」往后铺，装不下的部分留在下一格（原版潜影盒
     * 本来就允许有空位），所以 {@code count} 小于一盒容量时得到的就是一个「没装满的盒子」。</p>
     *
     * <p>{@code template} 只当样板用（数量无所谓），内部一律走
     * {@code copyWithCount(n)} 造新堆叠，<b>绝不把同一个实例挂在两处</b>。</p>
     */
    public static class_1799 pack(class_1799 template, long count) {
        int max = Math.max(1, template.method_7914());
        List<class_1799> slots = new ArrayList<>(BOX_SLOTS);
        long remaining = Math.max(0L, count);
        while (remaining > 0 && slots.size() < BOX_SLOTS) {
            int n = (int) Math.min(max, remaining);
            slots.add(template.method_46651(n));
            remaining -= n;
        }
        class_1799 box = new class_1799(class_1802.field_8545);
        if (!slots.isEmpty()) {
            // fromItems 会把内容压到前面（vanilla 的潜影盒本来就只存「非空的那几格」）。
            // 一个都没装时不写组件，交出一个真正「干净」的空盒子。
            box.method_57379(class_9334.field_49622, class_9288.method_57493(slots));
        }
        return box;
    }
}
