package neko.voidwarehouse;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4208;
import net.minecraft.class_4284;

/**
 * 「仓库终端」的登记表：世界上哪些坐标上的工作台是虚空仓库的入口。
 *
 * <h2>为什么要单独记一份坐标</h2>
 * <p>原版工作台<b>没有方块实体</b>，改名只是物品上的一个数据组件，放下之后那个名字就没了 ——
 * 所以「这个工作台是不是虚空仓库」不可能从方块本身读出来。加上一条硬约束：
 * 要让<b>纯原版客户端</b>也能用（方案 A），就不能给工作台加自定义方块状态 / 方块实体
 * （会改变方块状态数量与客户端注册表，原版客户端直接报错）。</p>
 *
 * <p>于是改用最轻的做法：<b>把位置记在存档里</b>。放下时登记、被破坏 / 被活塞推走时注销，
 * 查询时再顺手校验「这个坐标现在还是不是工作台」双保险。</p>
 *
 * <h2>登记与注销</h2>
 * <ul>
 *   <li>登记：{@code Block.setPlacedBy} —— 用「虚空仓库」物品放下一个工作台时（潜行 + 右键方块）；</li>
 *   <li>注销：{@code BlockBehaviour.affectNeighborsAfterRemoval} —— 方块被破坏 / 被替换 / 被活塞推走；</li>
 *   <li>兜底：同一个位置又放下一个<b>普通</b>工作台时也注销一次，
 *       万一上面两条因为外部编辑存档而漏了，也不会出现「普通工作台被当成仓库」的假终端。</li>
 * </ul>
 *
 * <p>存档固定写在主世界的 {@code SavedDataStorage} 上（与仓库内容同一份存档），
 * 记录用 {@link class_4208} 带上维度，所以跨维度的终端不会互相串。</p>
 */
public final class VoidWarehouseTerminals extends class_18 {
    private static final String TERMINALS_KEY = "terminals";

    public static final Codec<VoidWarehouseTerminals> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_4208.field_25066.listOf()
                    .optionalFieldOf(TERMINALS_KEY, List.of())
                    .forGetter(VoidWarehouseTerminals::rawList)
    ).apply(instance, VoidWarehouseTerminals::new));

    public static final class_10741<VoidWarehouseTerminals> TYPE = new class_10741<>(
            "carpet_neko_addition_void_warehouse_terminals",
            VoidWarehouseTerminals::new,
            CODEC,
            class_4284.field_19212);

    private final Set<class_4208> terminals = new HashSet<>();

    public VoidWarehouseTerminals() {
    }

    VoidWarehouseTerminals(List<class_4208> loaded) {
        this.terminals.addAll(loaded);
    }

    private List<class_4208> rawList() {
        return new ArrayList<>(this.terminals);
    }

    // ------------------------------------------------------------------ 查

    /**
     * 这个坐标上的方块是不是一个「仓库终端」。
     *
     * <p>三重判定：坐标必须是工作台（快筛，绝大多数调用在这里就返回了）、
     * 维度 + 坐标在登记表里、且规则是开着的。</p>
     */
    public static boolean isTerminal(class_3218 level, class_2338 pos) {
        if (!VoidWarehouseSettings.voidWarehouse) {
            return false;
        }
        if (!level.method_8320(pos).method_27852(class_2246.field_9980)) {
            return false;
        }
        return get(level).terminals.contains(class_4208.method_19443(level.method_27983(), pos.method_10062()));
    }

    /**
     * 这个坐标上的方块是不是一个「仓库入口」（工作台）。
     *
     * <p>与 {@link #isTerminal} 的区别：<b>不要求登记</b>。虚空仓库是全服唯一一份数据，
     * 所以「接了漏斗的工作台」本身就是入口 —— 不管它是改过名的终端，还是玩家随手放下的
     * 普通工作台。漏斗的入库 / 出料判定（{@link VoidWarehouseHopper#isIntake} /
     * {@link VoidWarehouseExtractor#isExtractor}）用的都是这一个宽松判定，
     * 与右键访问（{@link #isHopperConnected}）的语义保持一致：
     * <b>接了漏斗的工作台，就是仓库的进料口 / 出料口</b>。</p>
     */
    public static boolean isWorkbench(class_3218 level, class_2338 pos) {
        if (!VoidWarehouseSettings.voidWarehouse) {
            return false;
        }
        return level.method_8320(pos).method_27852(class_2246.field_9980);
    }

    /** 登记表里现在有多少个终端（诊断用） */
    public static int size(class_3218 level) {
        return get(level).terminals.size();
    }

    // ------------------------------------------------------------------ 漏斗连接

    /**
     * 这个工作台周围是不是有「相连」的漏斗（指向它、或被它指向）。
     *
     * <p>用途：一个<b>未改名</b>的原版工作台，只要接了漏斗，右键它也能访问仓库 ——
     * 这样玩家搭好自动化产线后，不需要再专门放一个改名工作台当入口，
     * 直接右键那条流水线上的工作台就能看仓库。</p>
     *
     * <p>相连的三种摆法（与原版漏斗的朝向约束一致，漏斗口没有「朝上」）：</p>
     * <ul>
     *   <li><b>工作台正上方</b>有漏斗、且它口朝下（{@code DOWN}）→ 指向工作台（入库）；</li>
     *   <li><b>工作台正下方</b>有漏斗 → 工作台在漏斗正上方（出料，见
     *       {@link VoidWarehouseExtractor}）；</li>
     *   <li><b>四个水平方向</b>有漏斗、且它口朝工作台 → 指向工作台（入库）。</li>
     * </ul>
     *
     * <p>只认工作台方块、且规则开着，其余情况快速返回 {@code false}。</p>
     */
    public static boolean isHopperConnected(class_3218 level, class_2338 pos) {
        if (!VoidWarehouseSettings.voidWarehouse) {
            return false;
        }
        if (!level.method_8320(pos).method_27852(class_2246.field_9980)) {
            return false;
        }
        // 正上方：漏斗口朝下才指向工作台
        if (isHopperFacing(level, pos.method_10084(), class_2350.field_11033)) {
            return true;
        }
        // 正下方：工作台在漏斗正上方（出料），任意朝向都算相连
        if (isHopper(level, pos.method_10074())) {
            return true;
        }
        // 四个水平方向：漏斗口朝工作台
        for (class_2350 side : class_2350.class_2353.field_11062) {
            if (isHopperFacing(level, pos.method_10093(side), side.method_10153())) {
                return true;
            }
        }
        return false;
    }

    /** 这个坐标上是漏斗、且它的口正好朝向 {@code facing} */
    private static boolean isHopperFacing(class_3218 level, class_2338 pos, class_2350 facing) {
        class_2680 state = level.method_8320(pos);
        return state.method_27852(class_2246.field_10312) && state.method_11654(class_2377.field_11129) == facing;
    }

    /** 这个坐标上是不是漏斗（不关心朝向） */
    private static boolean isHopper(class_3218 level, class_2338 pos) {
        return level.method_8320(pos).method_27852(class_2246.field_10312);
    }

    // ------------------------------------------------------------------ 写

    /** 把一个工作台登记成仓库终端 */
    public static void add(class_3218 level, class_2338 pos) {
        VoidWarehouseTerminals data = get(level);
        if (data.terminals.add(class_4208.method_19443(level.method_27983(), pos.method_10062()))) {
            data.method_80();
        }
    }

    /** 注销一个仓库终端（没有登记过就什么都不做） */
    public static void remove(class_3218 level, class_2338 pos) {
        VoidWarehouseTerminals data = get(level);
        if (data.terminals.remove(class_4208.method_19443(level.method_27983(), pos.method_10062()))) {
            data.method_80();
        }
    }

    /**
     * 取那份「全存档唯一」的登记表：固定挂在主世界的存档储存上，
     * 所以任何维度都能查到同一份登记（与 {@link VoidWarehouse#data} 同一处）。
     */
    private static VoidWarehouseTerminals get(class_3218 level) {
        return level.method_8503().method_30002().method_17983().method_17924(TYPE);
    }
}
