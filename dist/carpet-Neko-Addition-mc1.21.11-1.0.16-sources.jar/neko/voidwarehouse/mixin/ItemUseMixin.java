package neko.voidwarehouse.mixin;

import neko.voidwarehouse.VoidWarehouseTrigger;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 入口一：<b>对空气右键</b>。
 *
 * <p>{@code Item#use(Level, Player, InteractionHand)} 是物品右键的公共汇聚点，
 * 客户端和服务端都会走到（客户端走的是预测路径），所以在这里拦截
 * 既能开界面、又能阻止客户端做无用的预测。</p>
 *
 * <p>判定不通过时立即 return，对其它物品零影响。</p>
 */
@Mixin(class_1792.class)
public abstract class ItemUseMixin {

    @Inject(
            method = "use(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void carpetAutomending$voidWarehouseUse(class_1937 level, class_1657 player, class_1268 hand,
                                                    CallbackInfoReturnable<class_1269> cir) {
        class_1799 stack = player.method_5998(hand);
        if (!VoidWarehouseTrigger.isVoidWarehouse(stack)) {
            return;
        }
        cir.setReturnValue(VoidWarehouseTrigger.interact(level, player, hand));
    }
}
