package neko.voidwarehouse.mixin;

import neko.voidwarehouse.VoidWarehouseTrigger;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 入口三：<b>对着实体右键</b>。
 *
 * <p>右键实体的公共汇聚点是 {@code Player#interactOn(Entity, InteractionHand)}
 * （客户端 {@code MultiPlayerGameMode#interact} 和服务端都会调到这里），
 * 所以在这一个点就能同时覆盖双端。</p>
 *
 * <p>已核对 1.21.11 字节码：这里只有两个参数，<b>没有</b> 26.x 那个 {@code Vec3}
 * 命中点参数，描述符必须跟着改，否则注入会在运行时失败。</p>
 */
@Mixin(class_1657.class)
public abstract class PlayerInteractOnMixin {

    @Inject(
            method = "interactOn(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void carpetAutomending$voidWarehouseInteractOn(class_1297 entity, class_1268 hand,
                                                           CallbackInfoReturnable<class_1269> cir) {
        class_1657 self = (class_1657) (Object) this;
        class_1799 stack = self.method_5998(hand);
        if (!VoidWarehouseTrigger.isVoidWarehouse(stack)) {
            return;
        }
        cir.setReturnValue(VoidWarehouseTrigger.interact(self.method_73183(), self, hand));
    }
}
