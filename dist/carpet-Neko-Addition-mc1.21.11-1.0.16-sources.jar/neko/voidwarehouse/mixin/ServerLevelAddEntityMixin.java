package neko.voidwarehouse.mixin;

import neko.voidwarehouse.VoidWarehouseBlockDrops;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 收料口：{@code ServerLevel#addFreshEntity} 的 HEAD。
 *
 * <h2>为什么是这里</h2>
 * <p>方块掉落物在服务端的唯一落地方式就是「造一个 {@link class_1542}、把它加进世界」——
 * {@code Block#popResource} 的最后一步就是 {@code level.addFreshEntity(itemEntity)}。
 * 所以拦在这里，等于拦住了<b>所有</b>方块掉落物，且不用去碰任何一个具体方块的掉落逻辑
 * （附魔、幸运、时运、方块实体里的东西，全都照原版算完再交给我们）。</p>
 *
 * <p>拦在 HEAD 而不是里面更深的地方，是因为这里的语义最干净：实体还没进世界，
 * 拦下来就等于「它从来没存在过」。反过来若让它先进了世界再删，中间那一帧的
 * 拾取判定、声音、粒子都得自己收拾。</p>
 *
 * <h2>不会被误伤的东西</h2>
 * <p>只有 {@link class_1542} 会被看一眼，而且还得满足「此刻正在某个玩家挖方块」
 * （{@link VoidWarehouseBlockDrops#collect} 的判据）。经验球、掉落发射物、
 * 怪物死亡掉落、玩家丢弃、爆炸掉落全都不满足，一律原样进世界。</p>
 */
@Mixin(class_3218.class)
public abstract class ServerLevelAddEntityMixin {

    @Inject(
            method = "addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z",
            at = @At("HEAD"),
            cancellable = true
    )
    private void carpetAutomending$blockDropsIntoWarehouse(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
        if (!(entity instanceof class_1542 item)) {
            return;
        }
        class_1799 stack = item.method_6983();
        if (VoidWarehouseBlockDrops.collect((class_3218) (Object) this, stack)) {
            // 已经进仓库了，这一份不能再进世界 —— 否则就是复制
            cir.setReturnValue(false);
        }
    }
}
