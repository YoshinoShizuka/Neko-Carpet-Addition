package neko.voidwarehouse.mixin;

import neko.voidwarehouse.VoidWarehouseSettings;
import neko.voidwarehouse.VoidWarehouseTerminals;
import neko.voidwarehouse.VoidWarehouseTrigger;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2626;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * <b>服务端「对方块右键」的最上游拦截</b>：{@code ServerPlayerGameMode#useItemOn}
 * 是服务端处理方块右键真正的最上游，比「方块自己的交互」和 {@code BlockItem#useOn} 都早。
 *
 * <h2>三个入口</h2>
 * <ol>
 *   <li><b>手里拿着「虚空仓库」</b>右键任意方块 → 开界面（保留原来的用法，不会误放下去）；</li>
 *   <li><b>右键一个已放置的仓库终端</b>（{@link VoidWarehouseTerminals}）→ 开界面，
 *       空手也行、手里拿着别的东西也行；</li>
 *   <li><b>右键一个接了漏斗的原版工作台</b>（{@link VoidWarehouseTerminals#isHopperConnected}）→
 *       开界面 —— 搭好流水线的普通工作台也能当入口。</li>
 * </ol>
 *
 * <h2>潜行 = 放置</h2>
 * <p>原版语义里「潜行 + 手上有物品」会绕过方块交互、直接走物品自己的逻辑。
 * 这里照抄这条规则原样放行，于是 <b>潜行 + 右键方块</b>就能把改名工作台放下去
 * （{@code BlockPlacedByMixin} 会把它登记成终端）；不潜行时右键永远只是开界面，
 * 玩家不会不小心把仓库摆一地。</p>
 *
 * <h2>抹掉客户端的幽灵方块</h2>
 * <p>纯原版客户端并不知道「这个工作台是仓库终端」，右键时会先本地预测「把手里的方块放下」，
 * 于是终端隔壁会闪出一个幽灵方块。服务端既然接管了这次交互，就顺手把两个位置的真实状态
 * 发回给该玩家，把预测彻底抹掉（否则错误预测会一直留在客户端，直到区块重载）。</p>
 */
@Mixin(net.minecraft.class_3225.class)
public abstract class ServerPlayerGameModeMixin {

    @Inject(
            method = "useItemOn(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void carpetAutomending$voidWarehouseUseItemOn(class_3222 player, class_1937 level, class_1799 stack,
                                                          class_1268 hand, class_3965 hitResult,
                                                          CallbackInfoReturnable<class_1269> cir) {
        if (level.method_8608() || !VoidWarehouseSettings.voidWarehouse) {
            return;
        }
        // 原版语义：潜行 + 手上有物品 = 绕过方块交互。必须放行，
        // 否则玩家没有任何办法把「虚空仓库」放到地上。
        if (player.method_21823() && !stack.method_7960()) {
            return;
        }
        boolean terminal = level instanceof class_3218 serverLevel
                && VoidWarehouseTerminals.isTerminal(serverLevel, hitResult.method_17777());
        boolean hopperLinked = level instanceof class_3218 serverLevel2
                && VoidWarehouseTerminals.isHopperConnected(serverLevel2, hitResult.method_17777());
        if (!terminal && !hopperLinked && !VoidWarehouseTrigger.isVoidWarehouse(stack)) {
            return;
        }
        class_1269 result = VoidWarehouseTrigger.interact(level, player, hand);
        if (result.method_23665() && level instanceof class_3218 serverLevel) {
            discardPredictedPlacement(serverLevel, player, hitResult);
        }
        cir.setReturnValue(result);
    }

    /**
     * 把「客户端可能已经预测放下的那个方块」的真实状态发回给该玩家。
     *
     * <p>原版 {@code ItemStack#useOn} 会放在点击面的相邻位置；如果那个位置是可替换方块
     * （草丛之类），则会替换点击位置本身 —— 所以两个位置都发一遍，最省事也最保险。</p>
     */
    private static void discardPredictedPlacement(class_3218 level, class_3222 player, class_3965 hit) {
        if (player.field_13987 == null) {
            // 自检里手工构造的 ServerPlayer 没有连接：不值得为此报错
            return;
        }
        player.field_13987.method_14364(new class_2626(level, hit.method_17777()));
        class_2338 adjacent = hit.method_17777().method_10093(hit.method_17780());
        if (!adjacent.equals(hit.method_17777())) {
            player.field_13987.method_14364(new class_2626(level, adjacent));
        }
    }
}
