package neko.voidwarehouse;

import java.math.BigInteger;
import net.minecraft.class_1263;
import net.minecraft.class_1278;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import net.minecraft.class_2614;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * 虚空仓库 → 漏斗 的<b>出料</b>（与 {@link VoidWarehouseHopper} 的入库正好相反）。
 *
 * <h2>怎么摆</h2>
 * <pre>
 *   [工作台 / 仓库终端]   ← 终端压在漏斗<b>正上方</b>
 *        [漏斗]          ← 口朝下（或朝任意方向），下方接容器
 *      [箱子 / 熔炉…]
 * </pre>
 * <p>原版漏斗天生就会「从<b>上方</b>的容器里抽东西」，而工作台不是容器，
 * 所以原版在这里是空操作。本类补上的正是这一段：<b>把上方的仓库终端当成料源</b>，
 * 按漏斗自己的内容去仓库里取料。<br>
 * 反方向那条（漏斗口<b>朝向</b>终端 = 往仓库里灌）仍然走
 * {@link VoidWarehouseHopper}，两者靠「漏斗口朝哪」区分，不会打架：
 * 同一条漏斗两个条件都满足时<b>以入库为准</b>（见 {@link #isExtractor}）。</p>
 *
 * <h2>漏斗的 5 格 = 分类物</h2>
 * <p>漏斗里摆着什么，仓库就只出什么：每一格里已有的那件物品就是一条「出料品类」，
 * 仓库按这个品类把料补进<b>同一格</b>，一直补到该格满
 * （{@code min(该物品的堆叠上限, 容器上限)}，圆石就是 64）。</p>
 * <ul>
 *   <li><b>空格子什么都不出</b>：分类是玩家摆出来的，仓库不会替玩家挑品类，
 *       所以「我不摆分类物 = 这里不出料」，语义明确、没有意外；</li>
 *   <li><b>只出分类过的品类</b>：仓库里另外 1600 种物品一个都不会从这里流出去；</li>
 *   <li><b>匹配是「物品 + 数据组件」</b>（{@link VoidWarehouseData#takeExact}）：
 *       漏斗里那把改过名的钻石剑不会去匹配普通的钻石剑，与仓库「一格一种形态」的模型一致。</li>
 * </ul>
 * <p><b>整条链都无速率上限</b>（两端都比原版快，谁也不拖累谁）：</p>
 * <ul>
 *   <li><b>仓库 → 漏斗</b>：{@link #pull} 不踩原版「每 8 gt 搬 1 个」的节流，
 *       每个 tick 都会把格子补满，所以漏斗永远是个满仓的缓冲；</li>
 *   <li><b>漏斗 → 下游容器</b>：{@link #eject} 接管原版的出料动作，<b>整格搬</b>
 *       （原版是每次 1 个），再叠上 {@code pushItemsTick} 收尾清零冷却
 *       （见 {@code HopperBlockEntityMixin#carpetAutomending$unlimitedCooldown}）——
 *       于是下游每个 tick 都能拿到漏斗那一刻的全部存货。</li>
 * </ul>
 * <p>两段加起来 = 与入库漏斗同一个口径：<b>一 tick 搬空</b>，只取决于下游容器接得下多少。</p>
 *
 * <h2>分类物永不被抽走（本功能的硬约束）</h2>
 * <p>漏斗天生会把自己的东西往下游推，推干净了分类也就没了。所以在取出模式下
 * {@link #eject} 会<b>接管原版的出料动作</b>：每格物品的<b>最后 1 个</b>永远留在漏斗里。</p>
 * <ul>
 *   <li>仓库还有料时：格子被 {@link #pull} 补满 → 下游按「整格搬」取用 → 格子始终 ≥ 2 → 正常出货；</li>
 *   <li>仓库的该物品<b>被抽空</b>时：格子停在那 1 个上（这就是「余量」），
 *       下游再也拿不走它 —— 于是<b>分类不会丢</b>，玩家也不用重新摆一遍。</li>
 * </ul>
 * <p>换句话说：<b>仓库的账可以归零，漏斗的分类物一定还剩 1 个</b>。
 * 不可堆叠物更彻底 —— 那唯一的一个也永远留着（见下面「不可堆叠物：标本 + 旁路」）。</p>
 *
 * <h2>不丢东西 / 不多东西</h2>
 * <p>取料走的是仓库自己的 {@link VoidWarehouseData#takeExact}：仓库扣多少，漏斗就加多少，
 * 两者记的是同一笔账；下游容器放不下时，原样留在漏斗里（{@code addItem} 会退回剩余堆叠），
 * 既不会凭空消失、也不会因为「先加后扣」出现复制窗口。</p>
 *
 * <h2>红石语义不变</h2>
 * <p>被红石锁存（{@code ENABLED = false}）时，调用方根本不会进到这里：
 * 原版整个漏斗停摆，本功能也不会「无视红石往外倒料」。
 * 只有漏斗被原版激活时，它才会「从上方抽料」——这一条和原版漏斗的语义一致。</p>
 *
 * <h2>不可堆叠物：标本 + 旁路（本轮新增）</h2>
 * <p>堆叠上限为 1 的物品（水桶、潜影盒、床、船、被拆过的工具、药水…）有个天然矛盾：
 * 格子只能装 1 个，而这 1 个既是「货」又是「分类物」——
 * <b>搬走就没分类、不搬就没货</b>。本轮之前这类物品<b>出不了料</b>（旧版这里写的是一条「已知限制」）。</p>
 * <p>现在改成「<b>标本 + 旁路</b>」：格子里那 1 个<b>永不搬走</b>
 * （它同时是分类声明和玩家在界面上看到的图标），出货则走「仓库 → 下游」直连 ——
 * {@link #ejectSpecimen} 每 tick 从仓库取 1 个、直接塞给下游容器。</p>
 * <ul>
 *   <li><b>玩家看得见</b>：标本永远在格子里，原版漏斗界面直接画得出来 ——
 *       不需要额外渲染、不需要网络通道、不需要客户端模组；</li>
 *   <li>{@link #pull} <b>一个字都不用改</b>：格子恒为 1/1，{@code room} 天然是 0；</li>
 *   <li>速率 = <b>每 tick 1 个</b>（20 个/秒），是原版漏斗 2.5 个/秒的 8 倍，
 *       也是「一次只能搬一件」的物品在物理上的上限；</li>
 *   <li>下游不收就<b>整笔撤回仓库</b>，不丢不复制。</li>
 * </ul>
 * <p>顺带也把<b>潜影盒</b>纳入了出料范围 —— 它本来就是堆叠上限 1 的物品，
 * 本轮之前同样卡在这条限制上。</p>
 */
public final class VoidWarehouseExtractor {
    /**
     * 每格至少要留住的个数。
     *
     * <p>这就是「余量」：不论仓库还有没有料，漏斗里每一种物品都至少剩这么多个，
     * 下游容器永远吸不走。改成 0 就等于「出完拉倒、分类物一并送走」，
     * 那样仓库一抽空分类就丢了，玩家得重新摆一遍 —— 不是我们要的行为。</p>
     *
     * <p>就是 {@link VoidWarehouseClassifier#KEEP}：<b>入库端的白名单也留同样多的余量</b>
     * （见 {@link VoidWarehouseHopper#drain} 的 {@code keepClassifiers}），
     * 两端共用同一个数，这里保留这个名字只是为了不改动已经写进文档的 API。</p>
     */
    public static final int KEEP_AS_CLASSIFIER = VoidWarehouseClassifier.KEEP;

    private VoidWarehouseExtractor() {
    }

    /**
     * 这个漏斗现在是不是一条「出料口」。
     *
     * <p>三个条件同时成立才是：</p>
     * <ol>
     *   <li>规则 {@code voidWarehouse} 开着；</li>
     *   <li><b>正上方</b>是工作台（{@link VoidWarehouseTerminals#isWorkbench}，不要求登记）；</li>
     *   <li>漏斗口<b>朝向</b>的方块<b>不是</b>工作台 —— 那条是入库。</li>
     * </ol>
     *
     * <p>第 3 条是优先级规则：一条漏斗同时「上方是工作台」且「口朝另一个工作台」时，
     * <b>入库优先</b>。这样本轮之前就搭好的机器行为一个字都不变，
     * 不会因为新功能突然开始往反方向倒料。</p>
     */
    public static boolean isExtractor(class_3218 level, class_2338 pos, class_2680 state) {
        if (!VoidWarehouseSettings.voidWarehouse) {
            return false;
        }
        if (!state.method_27852(class_2246.field_10312)) {
            // 理论上不会发生（只从漏斗自己的 tick / 出料里调用），防御性判断
            return false;
        }
        if (!VoidWarehouseTerminals.isWorkbench(level, pos.method_10084())) {
            return false;
        }
        class_2350 facing = state.method_11654(class_2377.field_11129);
        return !VoidWarehouseTerminals.isWorkbench(level, pos.method_10093(facing));
    }

    /**
     * 按漏斗里的分类物，从仓库里<b>补料</b>。
     *
     * <p>每个 tick 调用一次（不踩原版冷却），把每个「有分类物的格子」补到上限。
     * 仓库里没有这个品类、或者格子本来就满了，都是无损的空操作。</p>
     *
     * @return 本次补进漏斗的<b>物品个数</b>（只用于自检 / 诊断，正式逻辑不依赖它）
     */
    public static int pull(class_3218 level, class_2614 hopper) {
        VoidWarehouseData data = VoidWarehouse.data(level.method_8503());
        int moved = 0;
        int slots = hopper.method_5439();
        for (int i = 0; i < slots; i++) {
            class_1799 sample = hopper.method_5438(i);
            if (sample.method_7960()) {
                // 空格子 = 没分类：仓库不替玩家挑品类
                continue;
            }
            int limit = Math.max(1, hopper.method_58350(sample));
            int room = limit - sample.method_7947();
            if (room <= 0) {
                continue;
            }
            // 走统一的「取出」入口：成品有货就直接扣成品，成品一件都没有且规则允许时
            // 改用 9 合 1 兑换（例如分类物是铁块、仓库里只剩铁粒）。
            // 兑换的账由 withdraw 内部一次性提交，这里的 setItem 一定能成功，所以不需要回滚路径。
            VoidWarehouseData.Withdrawal withdrawal =
                    data.withdraw(sample, BigInteger.valueOf(room));
            if (withdrawal.isEmpty()) {
                continue;
            }
            int taken = withdrawal.taken();
            // 只加数量：分类物那件东西本身（含数据组件）原样不动，
            // 而且用 copyWithCount 造新实例，绝不把同一个 ItemStack 挂在两处（防复制）
            hopper.method_5447(i, sample.method_46651(sample.method_7947() + taken));
            moved += taken;
        }
        if (moved > 0) {
            hopper.method_5431();
        }
        return moved;
    }

    /**
     * 出料（接管原版 {@code ejectItems}）：把漏斗里的物品送进下游容器，
     * <b>但每格永远留下 {@link #KEEP_AS_CLASSIFIER} 个</b>，而且<b>整格搬</b>（无速率上限）。
     *
     * <h2>与原版的差别（两处）</h2>
     * <ol>
     *   <li><b>整格搬</b>：原版 {@code ejectItems} 是「从头扫、谁非空就 {@code removeItem(slot, 1)}
     *       搬走 1 个」；这里改成把该格<b>除余量以外的全部</b>一次性推下去。
     *       配合调用方在 {@code pushItemsTick} 收尾把冷却清零，下游每个 tick
     *       都能拿到漏斗那一刻的全部存货 —— 与入库端 {@code VoidWarehouseHopper}
     *       的「整格搬」是同一个口径。</li>
     *   <li><b>余量保护</b>：数量 ≤ {@link #KEEP_AS_CLASSIFIER} 的格子直接跳过 ——
     *       那是分类物，绝不能外流。</li>
     * </ol>
     * <p>于是：正常出货时格子被 {@link #pull} 补满 → 整格推下去；仓库抽空后
     * 格子只剩那 1 个分类物 → 跳过，下游容器<b>吸不走</b>它，分类不会丢。</p>
     *
     * <h2>下游容器的限制一条都不绕过</h2>
     * <p>搬运用的是原版自己的 {@link class_2614#method_11247}，所以「熔炉只收燃料、
     * 朝向过滤、堆叠上限、容器白名单」全部照旧生效。<b>装不下就是装不下</b>：
     * {@code addItem} 会把剩菜原样退回来，这里把退回来的那部分写回漏斗原格
     * （不是丢掉，也不是硬塞）—— 既不会丢东西，也不会让一次出料越过下游容量的上限。</p>
     *
     * @return 是否真的搬走了东西（原版用这个返回值决定要不要进 8 gt 冷却；
     *         本模组在 {@code pushItemsTick} 收尾把冷却清零，所以这个 8 不再起作用）
     */
    public static boolean eject(class_3218 level, class_2338 pos, class_2614 hopper) {
        class_2680 state = level.method_8320(pos);
        if (!(state.method_26204() instanceof class_2377)) {
            return false;
        }
        class_2350 facing = state.method_11654(class_2377.field_11129);
        class_1263 target = class_2614.method_11250(level, pos.method_10093(facing));
        if (target == null) {
            return false;
        }
        // 与原版一致的快筛：下游一个位置都放不下时直接返回，避免白跑 5 次 addItem
        class_2350 side = facing.method_10153();
        if (isFullContainer(target, side)) {
            return false;
        }
        boolean moved = false;
        int slots = hopper.method_5439();
        for (int i = 0; i < slots; i++) {
            class_1799 stack = hopper.method_5438(i);
            if (stack.method_7960()) {
                // 空格子没东西可搬
                continue;
            }
            // 不可堆叠物（堆叠上限 1）：这一格那 1 个是「标本」，<b>永不搬走</b> ——
            // 它既是分类声明，也是玩家在漏斗界面里看到的那个图标。
            // 出货走「仓库 → 下游」直连（见 ejectSpecimen），标本一动不动。
            if (stack.method_7914() <= 1) {
                if (ejectSpecimen(level, hopper, target, side, stack)) {
                    moved = true;
                }
                continue;
            }
            if (stack.method_7947() <= KEEP_AS_CLASSIFIER) {
                // 只剩分类物的格子**不许搬** —— 下游容器不能吸收分类物
                continue;
            }
            // 整格搬：留下 KEEP_AS_CLASSIFIER 个当分类物，其余全部推下去
            int payload = stack.method_7947() - KEEP_AS_CLASSIFIER;
            class_1799 leftover = class_2614.method_11260(hopper, target, stack.method_46651(payload), side);
            int accepted = payload - leftover.method_7947();
            if (accepted <= 0) {
                // 下游这一格吃不下（满 / 不是它收的品类）→ 换下一格试试
                continue;
            }
            // 只减掉真被收下的那部分：退回来的（leftover）原样留在漏斗这一格里。
            // 用 copyWithCount 造新实例，绝不把同一个 ItemStack 挂在两处（防复制）。
            hopper.method_5447(i, stack.method_46651(stack.method_7947() - accepted));
            moved = true;
        }
        if (moved) {
            target.method_5431();
            hopper.method_5431();
        }
        return moved;
    }

    /**
     * <b>不可堆叠物的出料：标本留在漏斗里，货从仓库直连下游。</b>
     *
     * <h2>为什么不能沿用「留 1 个当余量」那一套</h2>
     * <p>堆叠上限为 1 的物品（水桶、潜影盒、床、被拆过的工具…），一格<b>最多就装 1 个</b>，
     * 而这 1 个同时扮演两个角色：它是「货」，也是「分类物」。
     * {@link #eject} 的老规矩是「每格只搬走 {@link #KEEP_AS_CLASSIFIER} 个以外的部分」，
     * 于是这类物品的 {@code 数量 - KEEP} 恒为 0 —— <b>永远搬不动</b>，
     * 本轮之前它们确实出不了料（旧版类注释里那条「已知限制」）。</p>
     * <p>把余量改成 0 也不行：搬空之后 {@link #pull} 就不知道该往这一格补什么了
     * （仓库不替玩家挑品类），于是出 1 个就断供，分类也跟着丢。</p>
     *
     * <h2>标本 + 旁路</h2>
     * <p>所以这一格那 1 个<b>干脆不动</b>：它从此只当「标本」（分类声明 + 界面上的图标），
     * 出货改走<b>仓库 → 下游</b>的直连 —— 每 tick 从仓库取 1 个，
     * 用原版 {@link class_2614#method_11247} 塞进下游容器，<b>完全不碰漏斗格子</b>。</p>
     * <ul>
     *   <li><b>看得见</b>：标本永远在格子里，原版漏斗界面直接就能画出这个物品，
     *       不需要额外渲染、不需要网络通道、不需要客户端模组；</li>
     *   <li><b>{@link #pull} 一个字不用改</b>：格子恒为 1/1，{@code room} 天然是 0；</li>
     *   <li><b>速率</b>：每 tick 1 个 = 20 个/秒，是原版漏斗（2.5 个/秒）的 8 倍；
     *       这也是「一次只能搬一件」的物品在物理上的上限；</li>
     *   <li><b>不丢不复制</b>：下游不收就整笔撤回仓库（{@link VoidWarehouseData.Withdrawal#returnUnplaced}），
     *       取货走 {@link VoidWarehouseData#withdraw}，仓库扣多少下游就收多少。</li>
     * </ul>
     *
     * <h2>为什么给 {@code addItem} 的是副本</h2>
     * <p>{@code addItem} 会<b>就地 shrink</b> 传进去的那个堆叠。而
     * {@link VoidWarehouseData.Withdrawal#returnUnplaced} 是拿它自己保存的那个堆叠的
     * <b>当前数量</b>去算「该退多少」的 —— 直接喂原件，撤销量会算成 0，下游一拒收就丢东西。
     * 所以这里先 {@code copy()} 一份给 {@code addItem}，撤销时仍以「原本要送几个」为准。</p>
     *
     * @param sample 漏斗这一格里的标本（只读，绝不修改）
     * @return 是否真的送出去了东西（下游收下了至少 1 个）
     */
    private static boolean ejectSpecimen(class_3218 level, class_2614 hopper, class_1263 target,
                                         class_2350 side, class_1799 sample) {
        VoidWarehouseData data = VoidWarehouse.data(level.method_8503());
        // 取 1 个：不可堆叠物一次也只能搬 1 个，多取没有意义
        VoidWarehouseData.Withdrawal withdrawal = data.withdraw(sample, BigInteger.ONE);
        if (withdrawal.isEmpty()) {
            // 仓库这件没货了（或者换不出来）→ 什么都不做，标本原样留着
            return false;
        }
        class_1799 cargo = withdrawal.stack();
        int want = cargo.method_7947();
        // 给副本：addItem 会就地 shrink 参数，而撤销要按「原本要送几个」算
        class_1799 leftover = class_2614.method_11260(hopper, target, cargo.method_7972(), side);
        int accepted = want - leftover.method_7947();
        if (accepted <= 0) {
            // 下游一个都收不下（满了 / 不是它收的品类）→ 整笔撤回仓库，绝不丢东西
            withdrawal.returnUnplaced(0);
            return false;
        }
        if (!leftover.method_7960()) {
            // 部分收下（理论上不可堆叠物只会是 0 或全部，这里按实际收下的数量记账）
            withdrawal.returnUnplaced(accepted);
        }
        return true;
    }

    /**
     * 复刻原版 {@code HopperBlockEntity#isFullContainer}：这个容器现在一个位置都放不下吗。
     *
     * <p>原版这个方法在 {@code ejectItems} 开头做快筛，我们用自己的一套出料逻辑，
     * 所以也要有一份等价物，否则「下游塞满」的情况下每个 tick 都会白跑 5 次
     * {@code addItem}（每次都还要遍历目的容器的全部槽位）。</p>
     *
     * <p>{@link class_1278} 的侧面过滤（熔炉只从上面收原料、箱子四面都收…）
     * 走 {@code getSlotsForFace}，与原版同一套判断。</p>
     */
    private static boolean isFullContainer(class_1263 container, class_2350 side) {
        if (container instanceof class_1278 worldly) {
            int[] slots = worldly.method_5494(side);
            for (int slot : slots) {
                if (!isSlotFull(container, slot)) {
                    return false;
                }
            }
            return true;
        }
        int size = container.method_5439();
        for (int slot = 0; slot < size; slot++) {
            if (!isSlotFull(container, slot)) {
                return false;
            }
        }
        return true;
    }

    private static boolean isSlotFull(class_1263 container, int slot) {
        class_1799 stack = container.method_5438(slot);
        if (stack.method_7960()) {
            return false;
        }
        return stack.method_7947() >= Math.max(1, container.method_58350(stack));
    }
}
