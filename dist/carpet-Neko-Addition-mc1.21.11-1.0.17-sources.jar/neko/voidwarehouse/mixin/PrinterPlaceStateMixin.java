package neko.voidwarehouse.mixin;

import neko.voidwarehouse.restock.PrinterPlaceServuxBridge;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lower-priority mixins prepend HEAD injections after Servux (950); run this scoped handler first. */
@Mixin(value = class_1747.class, priority = 900)
public abstract class PrinterPlaceStateMixin {
    @Shadow protected abstract boolean canPlace(class_1750 context, class_2680 state);

    @Inject(method = "getPlacementState", at = @At("HEAD"), cancellable = true)
    private void neko$structuredPlacement(class_1750 context, CallbackInfoReturnable<class_2680> result) {
        class_1747 item = (class_1747) (Object) this;
        if (!PrinterPlaceServuxBridge.matches(item, context)) return;
        class_2680 state = PrinterPlaceServuxBridge.scopedState(item, context);
        result.setReturnValue(state != null && state.method_26184(context.method_8045(), context.method_8037())
                && this.canPlace(context, state)
                && context.method_8045().method_8628(state, context.method_8037(),
                    net.minecraft.class_3726.method_67715(context.method_8036())) ? state : null);
    }
}
