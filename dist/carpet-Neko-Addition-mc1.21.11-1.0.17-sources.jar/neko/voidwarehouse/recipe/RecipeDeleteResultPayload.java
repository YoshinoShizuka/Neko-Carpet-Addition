package neko.voidwarehouse.recipe;

import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 服务端 → 客户端：删除的回执。
 *
 * <h2>为什么逐条回执，而不是只回一个成功标志</h2>
 * <p>一批里可能「删掉 3 条、2 条早就不在了」（另一个玩家刚删过）。客户端如果乐观删除后
 * 只收一个 {@code ok}，界面就会和真相分叉；逐条 {@link Failure} 才能让它把失败的挂回去。
 * 与打印机那条 {@code printer_take_result} 同一个思路：<b>回执要能自解释</b>。</p>
 *
 * <h2>为什么还要回 {@link #remaining}</h2>
 * <p>界面顶部通常写着「已用 N / 2048」。删完不回这个数，客户端就得再发一次索引才知道 ——
 * 多一个来回，还多一个状态不一致的窗口。</p>
 */
public record RecipeDeleteResultPayload(int status, List<String> removed, List<Failure> failed,
                                        int generation, int remaining, boolean canDelete)
        implements class_8710 {

    /** 回执通道：{@code carpet_neko_addition:recipe_delete_result}（S2C） */
    public static final class_8710.class_9154<RecipeDeleteResultPayload> TYPE =
            new class_8710.class_9154<>(
                    class_2960.method_60655("carpet_neko_addition", "recipe_delete_result"));

    /** 全部成功 */
    public static final int OK = 0;
    /** 部分成功：成功的在 {@code removed}，失败的在 {@code failed} */
    public static final int PARTIAL = 1;
    /** 一条都没删掉（全部 NOT_FOUND） */
    public static final int NOTHING = 2;
    /** 一包里超过 {@link RecipeDeletePayload#MAX_IDS} 条，整包没有执行 */
    public static final int TOO_MANY = 3;
    /** 撞上限流，本次请求不作数 */
    public static final int THROTTLED = 4;
    /** 规则没开（正常情况下服务端会直接丢弃，不会回这条） */
    public static final int RULE_OFF = 5;

    /** 失败原因：本子里没有这个 id（可能刚被别人删掉，也可能从来不存在） */
    public static final int NOT_FOUND = 0;
    /** 失败原因：id 是空串 / 长得不像一个 id（长度超上限） */
    public static final int BAD_ID = 1;

    /** 回执里最多列多少条删除成功 / 失败（与请求侧的批上限一致） */
    public static final int MAX_LIST = RecipeDeletePayload.MAX_IDS;

    /** 一条失败记录：哪个 id、为什么 */
    public record Failure(String id, int reason) {
        private static final class_9139<class_2540, Failure> CODEC = class_9139.method_56435(
                class_9135.field_48554, Failure::id,
                class_9135.field_48550, Failure::reason,
                Failure::new
        );
    }

    private static final class_9139<ByteBuf, List<String>> REMOVED_CODEC =
            class_9135.<ByteBuf, String>method_58000(MAX_LIST).apply(class_9135.field_48554);

    private static final class_9139<class_2540, List<Failure>> FAILED_CODEC =
            class_9135.<class_2540, Failure>method_58000(MAX_LIST).apply(Failure.CODEC);

    public static final class_9139<class_2540, RecipeDeleteResultPayload> CODEC =
            class_9139.method_58025(
                    class_9135.field_48550, RecipeDeleteResultPayload::status,
                    REMOVED_CODEC, RecipeDeleteResultPayload::removed,
                    FAILED_CODEC, RecipeDeleteResultPayload::failed,
                    class_9135.field_48550, RecipeDeleteResultPayload::generation,
                    class_9135.field_48550, RecipeDeleteResultPayload::remaining,
                    class_9135.field_48547, RecipeDeleteResultPayload::canDelete,
                    RecipeDeleteResultPayload::new
            );

    /** 整包失败（限流 / 超限 / 规则关）：没有删任何东西 */
    public static RecipeDeleteResultPayload refused(int status, int generation, int remaining,
                                                   boolean canDelete) {
        return new RecipeDeleteResultPayload(status, List.of(), List.of(), generation, remaining, canDelete);
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
