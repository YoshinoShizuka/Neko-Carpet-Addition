package neko.voidwarehouse.recipe;

import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 服务端 → 客户端：一页配方明细。
 *
 * <h2>{@code recipeId} 是 opaque 的</h2>
 * <p>它由配方内容算出（同一条配方学两次得到同一个 id），客户端<b>只能拿它当键</b>：
 * 不解析、不拼接、不比较大小、不假设长度上限以外的东西。删除时原样回传。</p>
 *
 * <h2>{@code parts} 里为什么是候选集合</h2>
 * <p>配方模型的原料是「任意一种候选物品各 {@code count} 个」（例如「任意木板」）。
 * 当前版本从合成格记录，候选恒为单元素，但结构留着多候选 —— 客户端按
 * 「candidates 里任意一个」渲染即可，将来填多候选不用改协议。</p>
 *
 * <h2>{@code generation} 的用法</h2>
 * <p>客户端拿它比自己缓存的版本：不一致就丢弃这一页重新请求。
 * 删除 / 学习都会让它自增，所以「正在看的页被别人改过」一定能被发现。</p>
 */
public record RecipePagePayload(int protocol, int generation, int page, int total, List<Entry> entries)
        implements class_8710 {

    /** 明细通道：{@code carpet_neko_addition:recipe_page}（S2C） */
    public static final class_8710.class_9154<RecipePagePayload> TYPE =
            new class_8710.class_9154<>(
                    class_2960.method_60655("carpet_neko_addition", "recipe_page"));

    /** 协议版本，与 {@link RecipeIndexPayload#PROTOCOL} 必须一致 */
    public static final int PROTOCOL = RecipeIndexPayload.PROTOCOL;

    /** 一页最多几条（与 {@link RecipeQueryPayload#MAX_PAGE_SIZE} 必须一致，否则解码侧会截断） */
    public static final int MAX_ENTRIES = RecipeQueryPayload.MAX_PAGE_SIZE;

    /** 一条配方最多几项原料（合成格是 3×3，理论上 9 项；留到 16 给将来的大配方） */
    public static final int MAX_PARTS = 16;

    /** 一项原料最多几个候选（当前恒为 1） */
    public static final int MAX_CANDIDATES = 16;

    /**
     * 一项原料：任意一种候选物品各 {@code count} 个。
     *
     * <p>顺序有意义：客户端展示时按这个顺序列，服务端不重排 ——
     * 同一份存档、同一条配方，两次看到的原料顺序永远一样。</p>
     */
    public record Part(List<String> candidates, int count) {
        static final class_9139<ByteBuf, List<String>> CANDIDATES_CODEC =
                class_9135.<ByteBuf, String>method_58000(MAX_CANDIDATES).apply(class_9135.field_48554);

        static final class_9139<class_2540, Part> CODEC = class_9139.method_56435(
                CANDIDATES_CODEC, Part::candidates,
                class_9135.field_48550, Part::count,
                Part::new
        );
    }

    /** 一条配方：产物 + 一次产出几个 + 原料清单 */
    public record Entry(String recipeId, String output, int outputCount, List<Part> parts) {
        private static final class_9139<class_2540, List<Part>> PARTS_CODEC =
                class_9135.<class_2540, Part>method_58000(MAX_PARTS).apply(Part.CODEC);

        static final class_9139<class_2540, Entry> CODEC = class_9139.method_56905(
                class_9135.field_48554, Entry::recipeId,
                class_9135.field_48554, Entry::output,
                class_9135.field_48550, Entry::outputCount,
                PARTS_CODEC, Entry::parts,
                Entry::new
        );
    }

    private static final class_9139<class_2540, List<Entry>> ENTRIES_CODEC =
            class_9135.<class_2540, Entry>method_58000(MAX_ENTRIES).apply(Entry.CODEC);

    public static final class_9139<class_2540, RecipePagePayload> CODEC = class_9139.method_56906(
            class_9135.field_48550, RecipePagePayload::protocol,
            class_9135.field_48550, RecipePagePayload::generation,
            class_9135.field_48550, RecipePagePayload::page,
            class_9135.field_48550, RecipePagePayload::total,
            ENTRIES_CODEC, RecipePagePayload::entries,
            RecipePagePayload::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
