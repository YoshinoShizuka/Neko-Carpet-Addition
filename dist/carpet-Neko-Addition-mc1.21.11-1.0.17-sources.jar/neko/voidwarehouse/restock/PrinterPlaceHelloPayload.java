package neko.voidwarehouse.restock;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Shared with litematica-printer; keep both copies identical. */
public record PrinterPlaceHelloPayload(int nonce) implements class_8710 {
    public static final class_9154<PrinterPlaceHelloPayload> TYPE = new class_9154<>(
            class_2960.method_60655("carpet_neko_addition", "printer_place_hello"));
    public static final class_9139<class_2540, PrinterPlaceHelloPayload> CODEC = new class_9139<>() {
        @Override
        public PrinterPlaceHelloPayload decode(class_2540 buf) {
            return new PrinterPlaceHelloPayload(buf.method_10816());
        }

        @Override
        public void encode(class_2540 buf, PrinterPlaceHelloPayload payload) {
            buf.method_10804(payload.nonce());
        }
    };

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
