package neko.voidwarehouse.restock;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Shared with litematica-printer; keep both copies identical. */
public record PrinterPlaceHelloResultPayload(int nonce, boolean enabled) implements class_8710 {
    public static final class_9154<PrinterPlaceHelloResultPayload> TYPE = new class_9154<>(
            class_2960.method_60655("carpet_neko_addition", "printer_place_hello_result"));
    public static final class_9139<class_2540, PrinterPlaceHelloResultPayload> CODEC = new class_9139<>() {
        @Override
        public PrinterPlaceHelloResultPayload decode(class_2540 buf) {
            return new PrinterPlaceHelloResultPayload(buf.method_10816(), buf.readBoolean());
        }

        @Override
        public void encode(class_2540 buf, PrinterPlaceHelloResultPayload payload) {
            buf.method_10804(payload.nonce());
            buf.method_52964(payload.enabled());
        }
    };

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
