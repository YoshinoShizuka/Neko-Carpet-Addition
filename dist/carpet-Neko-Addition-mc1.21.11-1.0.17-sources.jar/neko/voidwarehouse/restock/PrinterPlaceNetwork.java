package neko.voidwarehouse.restock;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2626;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.IdentityHashMap;
import java.util.Map;

/** Negotiation and replay protection are scoped to live connections, never reusable UUIDs. */
public final class PrinterPlaceNetwork {
    private static final Logger LOGGER = LoggerFactory.getLogger("carpet_neko_addition/printer_place");
    private static final Map<class_3244, PrinterPlaceSession> SESSIONS = new IdentityHashMap<>();
    private static long lastErrorAt;

    private PrinterPlaceNetwork() {
    }

    public static void init() {
        register(() -> PayloadTypeRegistry.playC2S().register(PrinterPlaceHelloPayload.TYPE, PrinterPlaceHelloPayload.CODEC));
        register(() -> PayloadTypeRegistry.playS2C().register(PrinterPlaceHelloResultPayload.TYPE, PrinterPlaceHelloResultPayload.CODEC));
        register(() -> PayloadTypeRegistry.playC2S().register(PrinterPlacePayload.TYPE, PrinterPlacePayload.CODEC));
        register(() -> PayloadTypeRegistry.playS2C().register(PrinterPlaceResultPayload.TYPE, PrinterPlaceResultPayload.CODEC));
        ServerPlayNetworking.registerGlobalReceiver(PrinterPlaceHelloPayload.TYPE, PrinterPlaceNetwork::hello);
        ServerPlayNetworking.registerGlobalReceiver(PrinterPlacePayload.TYPE, PrinterPlaceNetwork::handle);
        register(() -> PayloadTypeRegistry.playC2S().register(PrinterPlaceStatePayload.TYPE, PrinterPlaceStatePayload.CODEC));
        ServerPlayNetworking.registerGlobalReceiver(PrinterPlaceStatePayload.TYPE, PrinterPlaceNetwork::handleState);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> SESSIONS.remove(handler));
    }

    private static void register(Runnable registration) {
        try {
            registration.run();
        } catch (IllegalArgumentException alreadyRegisteredByClientMod) {
            // Integrated servers share the registry and the identical payload class with the printer.
        }
    }

    private static void hello(PrinterPlaceHelloPayload payload, ServerPlayNetworking.Context context) {
        class_3222 player = context.player();
        if (!ServerPlayNetworking.canSend(player, PrinterPlaceHelloResultPayload.TYPE)
                || !ServerPlayNetworking.canSend(player, PrinterPlaceResultPayload.TYPE)) {
            return;
        }
        PrinterPlaceSession session = SESSIONS.computeIfAbsent(player.field_13987, ignored -> new PrinterPlaceSession());
        if (session.allowHello(System.nanoTime())) {
            ServerPlayNetworking.send(player, new PrinterPlaceHelloResultPayload(payload.nonce(), PrinterPlaceService.enabled()));
        }
    }

    private static void handle(PrinterPlacePayload payload, ServerPlayNetworking.Context context) {
        handle(payload, null, context);
    }

    private static void handleState(PrinterPlaceStatePayload payload, ServerPlayNetworking.Context context) {
        handle(payload.placement(), payload, context);
    }

    private static void handle(PrinterPlacePayload payload, PrinterPlaceStatePayload structured,
                               ServerPlayNetworking.Context context) {
        class_3222 player = context.player();
        if (!ServerPlayNetworking.canSend(player, PrinterPlaceResultPayload.TYPE)) {
            return;
        }
        PrinterPlaceSession session = SESSIONS.get(player.field_13987);
        long now = System.nanoTime();
        int status;
        if (session == null || !session.negotiated()) {
            status = PrinterPlaceResultPayload.REJECTED;
        } else {
            status = session.begin(payload.nonce(), now, context.server().method_3780());
            if (status == -1) {
                // 直放的扣料提示要用「扣了哪一种、几个」，所以走 placeDetailed；
                // 状态码仍是同一套，place(...) 只是它的 .status() 简写。
                PrinterPlaceService.PlaceOutcome outcome = null;
                try {
                    outcome = structured == null
                            ? PrinterPlaceService.placeDetailed(context.server(), player, payload)
                            : PrinterPlaceService.placeDetailed(context.server(), player, structured);
                    status = outcome.status();
                } catch (RuntimeException failure) {
                    status = PrinterPlaceResultPayload.REJECTED;
                    if (now - lastErrorAt > 5_000_000_000L) {
                        lastErrorAt = now;
                        LOGGER.warn("Printer direct placement failed", failure);
                    }
                }
                session.complete(payload.nonce(), status);
                correct(player, payload);
                notifyDeducted(player, outcome);
            } else if (session.allowCorrection(now)) {
                // Replays and flooded requests get bounded authoritative correction traffic.
                correct(player, payload);
            }
        }
        ServerPlayNetworking.send(player, new PrinterPlaceResultPayload(payload.nonce(), status));
    }

    /**
     * 放置成功后记一笔「从仓库扣掉了什么」，具体合并与发送见 {@link PrinterPlaceNotifier}。
     *
     * <h2>为什么不在这里直接发消息</h2>
     * <p>直放是<b>全模组最高频</b>的动作：实机日志单个 10 秒窗口就有 334 次。
     * 一次一条会把聊天栏刷穿（每秒三十多行），所以记账与发送必须分开：
     * 这里只负责往汇总表里加一笔，真正的发送由 {@link PrinterPlaceNotifier#tick}
     * 按玩家每秒最多一条合并发出。</p>
     *
     * <h2>为什么整个包在 try 里</h2>
     * <p>提示是<b>附带</b>的。它若抛异常，绝不能反过来把「方块已经放好、料已经扣掉」
     * 判成失败 —— 那样客户端会重试，等于白扣一次料。所以这里吞掉一切异常，
     * 最坏的结果只是少一条提示。</p>
     */
    private static void notifyDeducted(class_3222 player, PrinterPlaceService.PlaceOutcome outcome) {
        try {
            PrinterPlaceNotifier.record(player, outcome);
        } catch (RuntimeException ignored) {
            // 记账失败只丢这一条提示，不影响放置结果
        }
    }

    private static void correct(class_3222 player, PrinterPlacePayload payload) {
        if (player.field_13987 == null || payload.hit() == null) {
            return;
        }
        class_3218 level = (class_3218) player.method_51469();
        correctPosition(player, level, payload.target());
        correctPosition(player, level, payload.hit().method_17777());
        correctPosition(player, level, payload.hit().method_17777().method_10093(payload.hit().method_17780()));
    }

    private static void correctPosition(class_3222 player, class_3218 level, class_2338 pos) {
        // Invalid requests must not load arbitrary chunks just to send their rejection.
        if (pos != null && !level.method_31606(pos) && level.method_22340(pos)
                && player.method_56093(pos, 1.0)) {
            player.field_13987.method_14364(new class_2626(level, pos));
        }
    }
}
