package neko.voidwarehouse.restock;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Shared with litematica-printer; target is the actual placement position before it changes. */
public record PrinterPlacePayload(int nonce, List<String> candidates, class_2338 target,
                                  class_3965 hit, int expectedStateId, String dimensionId) implements class_8710 {
    public static final int MAX_CANDIDATES = 8;
    public static final int MAX_ITEM_ID_LENGTH = 256;
    public static final class_9154<PrinterPlacePayload> TYPE = new class_9154<>(
            class_2960.method_60655("carpet_neko_addition", "printer_place"));
    public static final class_9139<class_2540, PrinterPlacePayload> CODEC = new class_9139<>() {
        @Override
        public PrinterPlacePayload decode(class_2540 buf) {
            int nonce = buf.method_10816();
            int size = buf.method_10816();
            if (size < 1 || size > MAX_CANDIDATES) {
                throw new IllegalArgumentException("Invalid direct-place candidate count: " + size);
            }
            List<String> candidates = new ArrayList<>(size);
            for (int i = 0; i < size; i++) {
                candidates.add(buf.method_10800(MAX_ITEM_ID_LENGTH));
            }
            class_2338 target = buf.method_10811();
            class_2338 clicked = buf.method_10811();
            class_2350 face = buf.method_10818(class_2350.class);
            class_243 location = new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble());
            class_3965 hit = new class_3965(location, face, clicked, buf.readBoolean());
            return new PrinterPlacePayload(nonce, List.copyOf(candidates), target, hit, buf.method_10816(), buf.method_10800(256));
        }

        @Override
        public void encode(class_2540 buf, PrinterPlacePayload payload) {
            int size = payload.candidates().size();
            if (size < 1 || size > MAX_CANDIDATES) {
                throw new IllegalArgumentException("Invalid direct-place candidate count: " + size);
            }
            buf.method_10804(payload.nonce());
            buf.method_10804(size);
            for (String candidate : payload.candidates()) {
                buf.method_10788(candidate, MAX_ITEM_ID_LENGTH);
            }
            buf.method_10807(payload.target());
            buf.method_10807(payload.hit().method_17777());
            buf.method_10817(payload.hit().method_17780());
            class_243 location = payload.hit().method_17784();
            buf.method_52940(location.field_1352);
            buf.method_52940(location.field_1351);
            buf.method_52940(location.field_1350);
            buf.method_52964(payload.hit().method_17781());
            buf.method_10804(payload.expectedStateId());
            buf.method_10788(payload.dimensionId(), 256);
        }
    };

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
