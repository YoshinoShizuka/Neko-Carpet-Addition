package neko.voidwarehouse.restock;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Shared with litematica-printer; keep both copies identical. */
public record PrinterPlaceResultPayload(int nonce, int status) implements class_8710 {
    public static final int OK = 0;
    public static final int RULE_OFF = 1;
    public static final int EMPTY = 2;
    public static final int REJECTED = 3;
    public static final int THROTTLED = 4;
    public static final int BAD_REQUEST = 5;
    public static final int STALE = 6;
    public static final class_9154<PrinterPlaceResultPayload> TYPE = new class_9154<>(
            class_2960.method_60655("carpet_neko_addition", "printer_place_result"));
    public static final class_9139<class_2540, PrinterPlaceResultPayload> CODEC = new class_9139<>() {
        @Override
        public PrinterPlaceResultPayload decode(class_2540 buf) {
            return new PrinterPlaceResultPayload(buf.method_10816(), buf.method_10816());
        }

        @Override
        public void encode(class_2540 buf, PrinterPlaceResultPayload payload) {
            buf.method_10804(payload.nonce());
            buf.method_10804(payload.status());
        }
    };

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
