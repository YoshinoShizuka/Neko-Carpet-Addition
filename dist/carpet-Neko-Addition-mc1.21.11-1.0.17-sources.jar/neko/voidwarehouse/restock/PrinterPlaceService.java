package neko.voidwarehouse.restock;

import neko.voidwarehouse.VoidWarehouse;
import neko.voidwarehouse.VoidWarehouseData;
import neko.voidwarehouse.VoidWarehouseSettings;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2320;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.math.BigInteger;
import java.util.List;

/** Ordinary block placement using one reserved warehouse item and a temporary hand copy. */
public final class PrinterPlaceService {
    private PrinterPlaceService() {
    }

    public static boolean enabled() {
        return VoidWarehouseSettings.voidWarehouse && VoidWarehouseRestockSettings.voidWarehouseRestock
                && VoidWarehouseRestockSettings.voidWarehouseDirectPlace;
    }

    /**
     * 一次直接放置的完整结果：状态码 + <b>真正被扣掉的那一种物品</b> + <b>扣了几个</b>。
     *
     * <h2>为什么不是直接返回状态码</h2>
     * <p>{@link #place} 的返回值原本只是一个 int，够判断成败，但没法支撑「扣料提示」——
     * 提示要说清扣的是<b>哪一种、几个</b>。把这两个数当成结果的一部分交出去，
     * service 就仍然只做纯逻辑（可单独跑自检、不依赖真玩家），
     * 「要不要发消息、怎么合并着发」全部留给网络层，与
     * {@code PrinterTakeService.TakeOutcome} 的分工完全一致。</p>
     *
     * <h2>{@code consumed} 是净扣减，不是预扣量</h2>
     * <p>放置流程是「先从仓库预扣 1 个 → 塞进手上临时格 → 走原版放置 → 没用掉的原样还回仓库」
     * （{@code Withdrawal#returnUnplaced}）。所以只有<b>放置真的发生</b>时这里才是 1；
     * 中途被拒（{@code REJECTED} / {@code STALE}）一律还回去，{@code consumed} 为 0，
     * 调用方据此不发提示 —— 报「消耗了 0 个」纯属噪音。</p>
     *
     * @param status   结果码，语义见 {@link PrinterPlaceResultPayload}
     * @param sample   这一轮命中的物品样板（数量恒 1）；一件都没命中时为 {@link class_1799#field_8037}
     * @param consumed 本次<b>净</b>从仓库扣掉的数量（失败 / 回滚时为 0）
     */
    public record PlaceOutcome(int status, class_1799 sample, int consumed) {

        /** 只有状态、没有数量的简写（失败路径用） */
        static PlaceOutcome of(int status) {
            return new PlaceOutcome(status, class_1799.field_8037, 0);
        }

        /** 真的放下了一个方块，并且真的从仓库扣了料 */
        public boolean deducted() {
            return this.status == PrinterPlaceResultPayload.OK && this.consumed > 0 && !this.sample.method_7960();
        }
    }

    public static int place(MinecraftServer server, class_3222 player, PrinterPlacePayload payload) {
        return placeDetailed(server, player, payload).status();
    }

    public static int place(MinecraftServer server, class_3222 player, PrinterPlaceStatePayload structured) {
        return placeDetailed(server, player, structured).status();
    }

    /** 与 {@link #place(MinecraftServer, class_3222, PrinterPlacePayload)} 同一条路径，但带出扣料明细 */
    public static PlaceOutcome placeDetailed(MinecraftServer server, class_3222 player, PrinterPlacePayload payload) {
        return placeDetailed(server, player, payload, null);
    }

    /** 与 {@link #place(MinecraftServer, class_3222, PrinterPlaceStatePayload)} 同一条路径，但带出扣料明细 */
    public static PlaceOutcome placeDetailed(MinecraftServer server, class_3222 player,
                                             PrinterPlaceStatePayload structured) {
        return structured == null ? PlaceOutcome.of(PrinterPlaceResultPayload.BAD_REQUEST)
                : placeDetailed(server, player, structured.placement(), structured);
    }

    private static PlaceOutcome placeDetailed(MinecraftServer server, class_3222 player, PrinterPlacePayload payload,
                                              PrinterPlaceStatePayload structured) {
        if (server == null || player == null || payload == null) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.BAD_REQUEST);
        }
        if (!enabled()) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.RULE_OFF);
        }
        if (structured != null && !PrinterPlaceServuxBridge.hasPermission(player)) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.REJECTED);
        }
        List<String> candidates = payload.candidates();
        if (payload.nonce() <= 0 || candidates == null || candidates.isEmpty()
                || candidates.size() > PrinterPlacePayload.MAX_CANDIDATES || !validHit(payload)) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.BAD_REQUEST);
        }
        class_3218 level = (class_3218) player.method_51469();
        if (!level.method_27983().method_29177().toString().equals(payload.dimensionId())) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.STALE);
        }
        class_2338 target = payload.target();
        class_2338 clicked = payload.hit().method_17777();
        if (player.field_13974.method_14257() != class_1934.field_9215 || !player.method_5805()
                || !player.method_7294() || player.method_6115() || player.field_7512 != player.field_7498
                || !allowedPosition(level, player, clicked) || !allowedPosition(level, player, target)
                || player.method_33571().method_1025(payload.hit().method_17784())
                    > Math.pow(player.method_55754() + 1.0, 2)) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.REJECTED);
        }
        if (class_2248.method_9507(level.method_8320(target)) != payload.expectedStateId()) {
            return PlaceOutcome.of(PrinterPlaceResultPayload.STALE);
        }

        boolean validItemId = false;
        boolean supportedItem = false;
        for (String raw : candidates) {
            if (raw == null || raw.isEmpty() || raw.length() > PrinterPlacePayload.MAX_ITEM_ID_LENGTH) {
                continue;
            }
            class_2960 id = class_2960.method_12829(raw);
            class_1792 item = id == null ? null : class_7923.field_41178.method_17966(id).orElse(null);
            if (item == null) {
                continue;
            }
            validItemId = true;
            // Dedicated subclasses can produce buckets, open interfaces or place multiple blocks.
            if (item.getClass() != class_1747.class) {
                continue;
            }
            class_1747 blockItem = (class_1747) item;
            class_2248 block = blockItem.method_7711();
            if (block instanceof class_2480 || block instanceof class_2244 || block instanceof class_2323
                    || block instanceof class_2320 || !item.method_45382(level.method_45162())) {
                continue;
            }
            supportedItem = true;
            class_1799 sample = new class_1799(item);
            if (player.method_7357().method_7904(sample) || !player.method_7343(target, payload.hit().method_17780(), sample)) {
                return PlaceOutcome.of(PrinterPlaceResultPayload.REJECTED);
            }
            class_1750 context = new class_1750(player, class_1268.field_5808, sample, payload.hit());
            if (!context.method_8037().equals(target) || !context.method_7716()) {
                return PlaceOutcome.of(PrinterPlaceResultPayload.REJECTED);
            }
            if (structured != null) {
                try {
                    class_2680 state = PrinterPlaceServuxBridge.placementState(blockItem, context, structured);
                    if (state == null || !state.method_26184(level, target)) {
                        return PlaceOutcome.of(PrinterPlaceResultPayload.REJECTED);
                    }
                } catch (IllegalArgumentException malformedProtocol) {
                    return PlaceOutcome.of(PrinterPlaceResultPayload.BAD_REQUEST);
                }
            }
            VoidWarehouseData.Withdrawal withdrawal = VoidWarehouse.data(server).withdraw(sample, BigInteger.ONE);
            if (withdrawal.isEmpty()) {
                continue;
            }
            // 净扣减由 placeReserved 的 finally 算出来（它才知道原版放置到底用掉了几个），
            // 这里先摆一个出口容器。用 int[] 而不是成员字段：这条路径是全服共享的热路径，
            // 不能为了带一个数出来引入任何可变状态。
            int[] consumed = new int[1];
            int status = placeReserved(player, level, blockItem, payload, structured, withdrawal, consumed);
            return new PlaceOutcome(status, sample, consumed[0]);
        }
        return PlaceOutcome.of(!validItemId ? PrinterPlaceResultPayload.BAD_REQUEST
                : !supportedItem ? PrinterPlaceResultPayload.REJECTED : PrinterPlaceResultPayload.EMPTY);
    }

    /**
     * 真正动世界的那一段：预扣的物品临时塞进手上、走原版放置、再把没用掉的还回去。
     *
     * @param consumedOut 出口容器：净扣减数量。必须由 {@code finally} 写 —— 只有那里
     *                    才同时知道「预扣了多少」和「放置用掉了多少」。
     */
    private static int placeReserved(class_3222 player, class_3218 level, class_1747 item,
                                     PrinterPlacePayload payload, PrinterPlaceStatePayload structured,
                                     VoidWarehouseData.Withdrawal withdrawal, int[] consumedOut) {
        // Withdrawal owns its original count for rollback, including exchange/crafting change.
        class_1799 temporary = withdrawal.stack().method_7972();
        int selected = player.method_31548().method_67532();
        class_1799 original = player.method_31548().method_5438(selected);
        class_2680 before = level.method_8320(payload.target());
        boolean enteredPlacement = false;
        boolean placementReturned = false;
        try {
            player.method_31548().method_5447(selected, temporary);
            class_1269 permission = UseBlockCallback.EVENT.invoker().interact(
                    player, level, class_1268.field_5808, payload.hit());
            if (permission != class_1269.field_5811) {
                return PrinterPlaceResultPayload.REJECTED;
            }
            // A callback may have changed the world or the held item; never place on an old snapshot.
            if (class_2248.method_9507(level.method_8320(payload.target())) != payload.expectedStateId()
                    || player.method_51469() != level || player.method_6047() != temporary
                    || player.field_7512 != player.field_7498) {
                return PrinterPlaceResultPayload.STALE;
            }
            class_1750 context = new class_1750(player, class_1268.field_5808, temporary, payload.hit());
            if (!context.method_8037().equals(payload.target()) || !context.method_7716()) {
                return PrinterPlaceResultPayload.REJECTED;
            }
            // Invoke the ordinary placement primitive, never the clicked block's interaction.
            // This keeps chests/composters/cauldrons from receiving the reserved item as an input.
            enteredPlacement = true;
            class_1269 result;
            if (structured == null) {
                result = item.method_7712(context);
            } else {
                try (PrinterPlaceServuxBridge.Scope ignored = PrinterPlaceServuxBridge.enter(item, context, structured)) {
                    result = item.method_7712(context);
                }
            }
            placementReturned = true;
            class_2680 after = level.method_8320(payload.target());
            return result.method_23665() && !before.equals(after) && temporary.method_7947() < withdrawal.taken()
                    ? PrinterPlaceResultPayload.OK : PrinterPlaceResultPayload.REJECTED;
        } finally {
            int consumed = Math.max(0, Math.min(withdrawal.taken(), withdrawal.taken() - temporary.method_7947()));
            player.method_31548().method_5447(selected, original);
            player.method_31548().method_61496(selected);
            if (enteredPlacement && (!placementReturned || !before.equals(level.method_8320(payload.target())))) {
                // Vanilla writes the block before sound/advancement/game-event hooks and consumption.
                // A throwing hook has an unknown partial outcome: never refund a possibly placed item.
                consumed = Math.max(consumed, 1);
            }
            withdrawal.returnUnplaced(consumed);
            // 出口容器放在「还回未用掉的那部分」之后写：真正记账的只有净扣减。
            if (consumedOut != null) {
                consumedOut[0] = consumed;
            }
        }
    }

    private static boolean validHit(PrinterPlacePayload payload) {
        class_2338 target = payload.target();
        class_3965 hit = payload.hit();
        if (target == null || hit == null || hit.method_17777() == null || hit.method_17780() == null
                || payload.expectedStateId() < 0 || hit.method_62877()) {
            return false;
        }
        class_2338 clicked = hit.method_17777();
        if (!target.equals(clicked) && !target.equals(clicked.method_10093(hit.method_17780()))) {
            return false;
        }
        class_243 location = hit.method_17784();
        // This hit is always physical; schematic state uses a separate semantic property map.
        return Double.isFinite(location.field_1352) && Double.isFinite(location.field_1351) && Double.isFinite(location.field_1350)
                && location.field_1352 >= clicked.method_10263() - 0.0001 && location.field_1352 <= clicked.method_10263() + 1.0001
                && location.field_1351 >= clicked.method_10264() - 0.0001 && location.field_1351 <= clicked.method_10264() + 1.0001
                && location.field_1350 >= clicked.method_10260() - 0.0001 && location.field_1350 <= clicked.method_10260() + 1.0001;
    }

    private static boolean allowedPosition(class_3218 level, class_3222 player, class_2338 pos) {
        return !level.method_31606(pos) && level.method_8621().method_11952(pos)
                && level.method_22340(pos) && player.method_56093(pos, 1.0)
                && player.method_36971(level, pos);
    }
}
