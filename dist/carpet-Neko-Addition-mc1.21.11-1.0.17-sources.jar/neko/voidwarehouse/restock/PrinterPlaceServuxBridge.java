package neko.voidwarehouse.restock;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_2771;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Resolves the exact block state a structured direct-place request asked for.
 *
 * <p>Servux ships a decoder for Litematica's easy-place protocol, but its metadata declares
 * {@code "environment": "server"}: Fabric never loads it on a client, so a single-player
 * integrated server can never offer that decoder. Structured placement therefore computes the
 * state itself and only borrows Servux when the mod really is present on a dedicated server.
 */
public final class PrinterPlaceServuxBridge {
    /**
     * The properties easy place is allowed to dictate, mirroring Servux's own table so a request
     * resolves to the same state whether or not that mod is installed. Every other property is
     * left at whatever the world and the player's aim produced.
     */
    private static final Set<class_2769<?>> WHITELISTED = Set.<class_2769<?>>of(
            class_2741.field_12501, class_2741.field_12537, class_2741.field_17104,
            class_2741.field_12496, class_2741.field_12518, class_2741.field_12555,
            class_2741.field_12506, class_2741.field_12534, class_2741.field_12520,
            class_2741.field_12525, class_2741.field_12545, class_2741.field_12481,
            class_2741.field_23333, class_2741.field_12507, class_2741.field_12542,
            class_2741.field_12485, class_2741.field_12503, class_2741.field_61445,
            class_2741.field_12505, class_2741.field_12494, class_2741.field_12524,
            class_2741.field_12532);

    /** Properties easy place must never dictate; the value the world produced always wins. */
    private static final Map<class_2769<?>, Comparable<?>> BLACKLISTED = Map.<class_2769<?>, Comparable<?>>of(
            class_2741.field_12508, Boolean.FALSE,
            class_2741.field_12484, Boolean.FALSE);

    private static final Binding API = bind();
    private static final ThreadLocal<Scope> CURRENT = new ThreadLocal<>();

    private PrinterPlaceServuxBridge() { }

    /** Whether Servux's decoder was found. Diagnostics only; placement never depends on it. */
    public static boolean servuxDecoderPresent() { return API != null; }

    /**
     * Servux gates easy place behind its own permission setting. Without it there is nothing to
     * ask: the warehouse rules plus the ordinary may-build checks are the only authority, exactly
     * as they are for the restock channel.
     */
    public static boolean hasPermission(class_3222 player) {
        if (player == null) return false;
        if (API == null) return true;
        try { return (boolean) API.permission.invoke(API.config, player); }
        catch (ReflectiveOperationException failure) { throw apiFailure(failure); }
    }

    private static Binding bind() {
        if (!FabricLoader.getInstance().isModLoaded("servux")) return null;
        try {
            Class<?> handler = Class.forName("fi.dy.masa.servux.util.PlacementHandler");
            Class<?> useContext = Class.forName("fi.dy.masa.servux.util.PlacementHandler$UseContext");
            Class<?> config = Class.forName("fi.dy.masa.servux.dataproviders.ServuxConfigProvider");
            return new Binding(config.getField("INSTANCE").get(null),
                    config.getMethod("hasPermission_EasyPlace", class_3222.class),
                    handler.getMethod("applyPlacementProtocolV3", class_2680.class, useContext),
                    useContext.getConstructor(class_1937.class, class_2338.class, class_2350.class, class_243.class,
                            class_1309.class, class_1268.class, class_1750.class));
        } catch (ReflectiveOperationException | LinkageError | ClassCastException failure) {
            LoggerFactory.getLogger("carpet_neko_addition/printer_place").warn(
                    "Servux placement API is unavailable; using the built-in structured decoder", failure);
            return null;
        }
    }

    /**
     * Validate semantic input against the actual item, then resolve it into the state to place.
     * The requested map is applied here; Servux only reproduces that same state when present.
     */
    public static class_2680 placementState(class_1747 item, class_1750 physical, PrinterPlaceStatePayload payload) {
        Map<String, String> requested = payload.properties();
        if (payload.blockId() == null || payload.blockId().length() > PrinterPlaceStatePayload.MAX_BLOCK_ID_LENGTH
                || !class_7923.field_41175.method_10221(item.method_7711()).toString().equals(payload.blockId())
                || requested == null || requested.size() > PrinterPlaceStatePayload.MAX_PROPERTIES) {
            throw new IllegalArgumentException("Invalid structured direct-place block");
        }
        class_2680 normal = item.method_7711().method_9605(physical);
        if (normal == null) return null;
        class_2680 desired = withRequested(normal, requested);
        if (API == null) return desired;
        class_243 protocolHit = protocolHit(normal, desired, physical.method_8037(), firstDirection(normal));
        try {
            // The original physical context remains the item context for Servux's placement checks.
            Object context = API.context.newInstance(physical.method_8045(), physical.method_8037(), physical.method_8038(),
                    protocolHit, physical.method_8036(), physical.method_20287(), physical);
            Object result = API.decode.invoke(null, normal, context);
            // Servux only decodes the bit field packed above for it. If the state it hands back does
            // not carry the properties the schematic asked for, that packed layout is out of sync
            // with the installed Servux. Placing it anyway would look like "the printer rotated the
            // block wrong" -- silent, and impossible to trace back to this line. Refuse instead.
            return result instanceof class_2680 state && requestedSurvived(normal, desired, state) ? state : null;
        } catch (ReflectiveOperationException failure) { throw apiFailure(failure); }
    }

    /** Apply the requested properties the way easy place does, keeping every world-driven one. */
    private static class_2680 withRequested(class_2680 normal, Map<String, String> requested) {
        class_2680 desired = normal;
        class_2769<?> firstDirection = firstDirection(normal);
        for (Map.Entry<String, String> entry : requested.entrySet()) {
            String name = entry.getKey();
            String value = entry.getValue();
            if (name == null || name.isBlank() || name.length() > PrinterPlaceStatePayload.MAX_PROPERTY_NAME_LENGTH
                    || value == null || value.length() > PrinterPlaceStatePayload.MAX_PROPERTY_VALUE_LENGTH) {
                throw new IllegalArgumentException("Invalid structured direct-place property");
            }
            class_2769<?> property = normal.method_26204().method_9595().method_11663(name);
            if (property == null) {
                throw new IllegalArgumentException("Unknown structured direct-place property");
            }
            Comparable<?> parsed = property.method_11900(value).orElse(null);
            if (parsed == null) {
                throw new IllegalArgumentException("Unknown structured direct-place property value");
            }
            boolean directional = property == firstDirection && property != class_2741.field_28062;
            if (BLACKLISTED.containsKey(property) || (!directional && !WHITELISTED.contains(property))) continue;
            // One reserved item cannot become two slabs. Easy place leaves that to a second pass,
            // where the ordinary place-on-slab rule turns the pair into the double slab asked for.
            if (class_2771.field_12682.equals(parsed)) continue;
            desired = with(desired, property, parsed);
        }
        return desired;
    }

    /** Pack semantic fields solely for the installed Servux public decoder, following its V3 wire field order. */
    private static class_243 protocolHit(class_2680 normal, class_2680 desired, class_2338 target, class_2769<?> firstDirection) {
        long fields = 0;
        int shift = 1;
        int count = 0;
        if (firstDirection != null && firstDirection != class_2741.field_28062) {
            fields |= (long) ((class_2350) desired.method_11654(firstDirection)).method_10146() << shift;
            shift += 3;
            count++;
        }
        List<class_2769<?>> properties = new ArrayList<>(normal.method_28501());
        properties.sort(Comparator.comparing(class_2769::method_11899));
        for (class_2769<?> property : properties) {
            if (property == firstDirection || !WHITELISTED.contains(property) || BLACKLISTED.containsKey(property)) continue;
            List<Comparable<?>> values = values(property);
            int width = 32 - Integer.numberOfLeadingZeros(values.size() - 1);
            if (shift + width > 30) throw new IllegalArgumentException("Unsupported Servux placement property layout");
            int index = values.indexOf(desired.method_11654(property));
            if (index < 0) throw new IllegalArgumentException("Unsupported Servux placement property value");
            fields |= (long) index << shift;
            shift += width;
            count++;
        }
        return count == 0 ? class_243.method_24954(target) : new class_243(target.method_10263() + 2.0 + fields, target.method_10264(), target.method_10260());
    }

    /**
     * Read-back check on the round trip through Servux: every property this bridge asked to change
     * must come back exactly as asked. Properties nobody touched are deliberately not compared --
     * Servux decodes from the same {@code normal} state, so only the encoded bits can drift.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private static boolean requestedSurvived(class_2680 normal, class_2680 desired, class_2680 actual) {
        if (actual.method_26204() != desired.method_26204()) {
            return false;
        }
        for (class_2769 property : desired.method_28501()) {
            Object asked = desired.method_11654(property);
            if (!asked.equals(normal.method_11654(property)) && !asked.equals(actual.method_11654(property))) {
                return false;
            }
        }
        return true;
    }

    private static class_2769<?> firstDirection(class_2680 state) {
        for (class_2769<?> property : state.method_28501()) {
            if (property instanceof class_2754<?> && property.method_11902() == class_2350.class) return property;
        }
        return null;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static List<Comparable<?>> values(class_2769<?> property) {
        List values = new ArrayList(property.method_11898());
        values.sort(Comparator.naturalOrder());
        return values;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static class_2680 with(class_2680 state, class_2769 property, Comparable value) { return state.method_11657(property, value); }

    private static IllegalStateException apiFailure(ReflectiveOperationException failure) {
        Throwable cause = failure instanceof InvocationTargetException invocation ? invocation.getCause() : failure;
        return new IllegalStateException("Servux placement API failed", cause);
    }

    public static Scope enter(class_1747 item, class_1750 physical, PrinterPlaceStatePayload payload) {
        Scope scope = new Scope(item, physical, payload, CURRENT.get());
        CURRENT.set(scope);
        return scope;
    }

    public static boolean matches(class_1747 item, class_1750 context) {
        Scope scope = CURRENT.get();
        return scope != null && scope.item == item && scope.context == context && context.method_8045() == scope.level
                && context.method_8036() == scope.player && context.method_8041() == scope.stack
                && context.method_8037().equals(scope.payload.placement().target());
    }

    public static class_2680 scopedState(class_1747 item, class_1750 context) {
        Scope scope = CURRENT.get();
        return matches(item, context) && scope.player instanceof class_3222 player && hasPermission(player)
                ? placementState(item, context, scope.payload) : null;
    }

    private record Binding(Object config, Method permission, Method decode, Constructor<?> context) { }

    public static final class Scope implements AutoCloseable {
        private final class_1747 item;
        private final class_1750 context;
        private final PrinterPlaceStatePayload payload;
        private final class_1937 level;
        private final net.minecraft.class_1657 player;
        private final class_1799 stack;
        private final Scope previous;

        private Scope(class_1747 item, class_1750 context, PrinterPlaceStatePayload payload, Scope previous) {
            this.item = item;
            this.context = context;
            this.payload = payload;
            this.level = context.method_8045();
            this.player = context.method_8036();
            this.stack = context.method_8041();
            this.previous = previous;
        }

        @Override public void close() {
            if (previous == null) CURRENT.remove();
            else CURRENT.set(previous);
        }
    }
}
