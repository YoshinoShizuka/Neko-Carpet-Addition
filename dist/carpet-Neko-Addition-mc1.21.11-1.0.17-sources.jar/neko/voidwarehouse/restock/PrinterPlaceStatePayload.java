package neko.voidwarehouse.restock;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Shared with litematica-printer; schematic properties are semantic data, never physical hit coordinates. */
public record PrinterPlaceStatePayload(PrinterPlacePayload placement, String blockId,
                                       Map<String, String> properties) implements class_8710 {
    public static final int MAX_PROPERTIES = 64;
    public static final int MAX_BLOCK_ID_LENGTH = 256;
    public static final int MAX_PROPERTY_NAME_LENGTH = 64;
    public static final int MAX_PROPERTY_VALUE_LENGTH = 128;
    public static final class_9154<PrinterPlaceStatePayload> TYPE = new class_9154<>(
            class_2960.method_60655("carpet_neko_addition", "printer_place_state_v1"));
    public static final class_9139<class_2540, PrinterPlaceStatePayload> CODEC = new class_9139<>() {
        @Override
        public PrinterPlaceStatePayload decode(class_2540 buf) {
            PrinterPlacePayload placement = PrinterPlacePayload.CODEC.decode(buf);
            String blockId = buf.method_10800(MAX_BLOCK_ID_LENGTH);
            int count = buf.method_10816();
            if (count < 0 || count > MAX_PROPERTIES) throw new IllegalArgumentException("Invalid direct-place property count");
            Map<String, String> properties = new LinkedHashMap<>();
            for (int i = 0; i < count; i++) {
                String name = buf.method_10800(MAX_PROPERTY_NAME_LENGTH);
                String value = buf.method_10800(MAX_PROPERTY_VALUE_LENGTH);
                if (name.isEmpty() || properties.putIfAbsent(name, value) != null) {
                    throw new IllegalArgumentException("Invalid or duplicate direct-place property name");
                }
            }
            return new PrinterPlaceStatePayload(placement, blockId, Map.copyOf(properties));
        }

        @Override
        public void encode(class_2540 buf, PrinterPlaceStatePayload payload) {
            Map<String, String> properties = payload.properties();
            if (properties.size() > MAX_PROPERTIES) throw new IllegalArgumentException("Invalid direct-place property count");
            PrinterPlacePayload.CODEC.encode(buf, payload.placement());
            buf.method_10788(payload.blockId(), MAX_BLOCK_ID_LENGTH);
            buf.method_10804(properties.size());
            for (Map.Entry<String, String> entry : properties.entrySet()) {
                if (entry.getKey().isEmpty()) throw new IllegalArgumentException("Invalid direct-place property name");
                buf.method_10788(entry.getKey(), MAX_PROPERTY_NAME_LENGTH);
                buf.method_10788(entry.getValue(), MAX_PROPERTY_VALUE_LENGTH);
            }
        }
    };

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
