package neko.voidwarehouse.restock;

import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 打印机 → 服务端：「我这里缺料了，从虚空仓库给我一组」。
 *
 * <p>这是客户端唯一能拿到仓库库存的途径 —— 仓库数据全在服务端 SavedData 里，
 * 客户端一个字节都读不到，所以只能「发个请求过去、等服务端把东西塞进背包」。</p>
 *
 * <h2>为什么带的是候选清单而不是单个物品</h2>
 * <p>打印机的 {@code MaterialRequest} 本来就允许「这类方块有好几种等价物品」，
 * 逐个发请求要来回好几趟。这里一次把候选都发过来，服务端按顺序找第一个仓库里真有的，
 * 一趟搞定，对打印流畅度影响很大。</p>
 *
 * <h2>{@code nonce} 的用处</h2>
 * <p>回执靠它和请求配对。打印机同一时刻只允许一个请求在飞，所以其实只要一个整数就够；
 * 保留它主要是为了「迟到的回执不会误导当前这一次请求」。</p>
 */
public record PrinterTakePayload(int nonce, List<String> candidates) implements class_8710 {

    /** 与 mod id 保持一致；第二个参数是通道名 */
    public static final class_8710.class_9154<PrinterTakePayload> TYPE =
            new class_8710.class_9154<>(
                    class_2960.method_60655("carpet_neko_addition", "printer_take"));

    /**
     * 一次最多带几个候选物品。
     *
     * <p>够用了（打印机常见情况也就一两个），同时也是防御：客户端再怎么出错也撑不大这个包。</p>
     */
    public static final int MAX_CANDIDATES = 8;

    /**
     * 候选物品清单的编解码器。
     *
     * <p>{@code list} 是 {@link net.minecraft.network.codec.StreamCodec.CodecOperation}，
     * 三个类型参数全靠推断 —— 直接写 {@code ByteBufCodecs.list(8)} 推断不出来会退化成 {@code Object}，
     * 所以这里必须显式写出 {@code <ByteBuf, String>}。<br>
     * 结果故意保留为 {@code StreamCodec<ByteBuf, ...>}（而不是 FriendlyByteBuf）：
     * {@code composite} 的形参是 {@code StreamCodec<? super B, T>}，
     * 用更宽的 {@code ByteBuf} 正好能被 26.3 与 1.21.11 两边同时接纳。</p>
     */
    private static final class_9139<ByteBuf, List<String>> CANDIDATES_CODEC =
            class_9135.<ByteBuf, String>method_58000(MAX_CANDIDATES).apply(class_9135.field_48554);

    public static final class_9139<class_2540, PrinterTakePayload> CODEC = class_9139.method_56435(
            class_9135.field_48550, PrinterTakePayload::nonce,
            CANDIDATES_CODEC, PrinterTakePayload::candidates,
            PrinterTakePayload::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
