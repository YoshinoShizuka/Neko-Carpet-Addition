package neko.voidwarehouse.restock;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 服务端 → 打印机：「刚才那次要货的结果」。
 *
 * <p>为什么需要回执，而不是让打印机自己盯着背包看：仓库里<b>根本没这件东西</b>时，
 * 盯背包的人要干等到超时才知道白等了 —— 打印一个大面积投影要缺料几十次，
 * 每次卡上几十 tick，体验会非常糟。有了回执，没货立刻被告知，
 * 责任链可以继续往下走或者干脆标记缺料。</p>
 *
 * <p>反过来，成功时仍然以「背包里真的出现了这个物品」为准
 * （{@code take-OK} 只代表服务端发货了），两边取交集最稳。</p>
 */
public record PrinterTakeResultPayload(int nonce, int status) implements class_8710 {

    public static final class_8710.class_9154<PrinterTakeResultPayload> TYPE =
            new class_8710.class_9154<>(
                    class_2960.method_60655("carpet_neko_addition", "printer_take_result"));

    /** 成功：服务端已经把东西放进玩家背包 */
    public static final int OK = 0;
    /** 拒绝：Carpet 规则 {@code voidWarehouseRestock} 没开 */
    public static final int RULE_OFF = 1;
    /** 仓库里一件都没有（候选全军覆没） */
    public static final int EMPTY = 2;
    /** 背包塞不下，一件都没给（仓库也没扣，不会产生幽灵消耗） */
    public static final int INVENTORY_FULL = 3;
    /** 撞上限流：客户端发太快 */
    public static final int THROTTLED = 4;
    /** 包本身不合法（候选为空 / 物品 id 解析不出来） */
    public static final int BAD_REQUEST = 5;

    public static final class_9139<class_2540, PrinterTakeResultPayload> CODEC = class_9139.method_56435(
            class_9135.field_48550, PrinterTakeResultPayload::nonce,
            class_9135.field_48550, PrinterTakeResultPayload::status,
            PrinterTakeResultPayload::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
