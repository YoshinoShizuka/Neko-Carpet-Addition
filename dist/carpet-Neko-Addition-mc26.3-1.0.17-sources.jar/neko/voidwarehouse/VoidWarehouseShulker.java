package neko.voidwarehouse;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.ShulkerBoxBlock;

import java.util.ArrayList;
import java.util.List;

/**
 * 「潜影盒打包 / 拆解」的全部规则，集中在这一个类里。
 *
 * <h2>为什么要这么做</h2>
 * <p>仓库的模型是「一种物品 = 一格，数量无上限」。潜影盒恰好是原版里唯一能让玩家
 * <b>自己决定一格装多少</b>的容器，所以把它当作仓库的「打包单位」最自然：
 * 存的时候把盒子拆成原料，取的时候再按原料现造一个盒子。
 * 这样仓库里永远只有「纯净的散件」，不会有成千上万个「装着不同东西的潜影盒」把格子撑爆。</p>
 *
 * <h2>换算规则（原版配方）</h2>
 * <pre>
 *   1 个潜影盒 = 2 个潜影壳 + 1 个箱子
 *   1 个染色潜影盒 = 2 个潜影壳 + 1 个箱子 + 1 个对应颜色的染料
 *   1 盒能装 = 27 格 × 该物品的堆叠上限
 *              （圆石这类 64 → 1728；末影珍珠这类 16 → 432；床这类 1 → 27）
 * </pre>
 * <p>所以「取出 1 个装满圆石的潜影盒」= 扣 1728 个圆石 + 2 个潜影壳 + 1 个箱子；
 * 「存入 1 个装着 3 种东西的潜影盒」= 加那 3 种物品各自的真实数量 + 2 个潜影壳 + 1 个箱子。
 * 两个方向都严格守恒，不多不少。</p>
 *
 * <p><b>染色盒的染料也要还</b>：原版里染色盒是「任意潜影盒 + 1 个对应染料」合成的，
 * 所以拆一个染色盒必须吐出 {@code 2 壳 + 1 箱 + 1 染料} —— 只还壳和箱等于把玩家那个
 * 染料吞了。见 {@link #dyeOf(ItemStack)}。</p>
 *
 * <h2>识别</h2>
 * <p>26.3 里没有 {@code ShulkerBoxItem} 这个类，潜影盒是 <b>普通 {@code BlockItem}</b>
 * （方块是 {@link ShulkerBoxBlock}），所以用「物品是 BlockItem 且它的方块是潜影盒」
 * 来识别 —— 这样<b>带颜色的潜影盒也一并认出来</b>，不需要枚举 16 种颜色。</p>
 */
public final class VoidWarehouseShulker {
    /** 一个潜影盒的容纳格数（原版固定 27 格） */
    public static final int BOX_SLOTS = 27;

    /** 合成 1 个潜影盒需要的潜影壳数量（原版配方） */
    public static final int SHELL_COST = 2;

    /** 合成 1 个潜影盒需要的箱子数量（原版配方） */
    public static final int CHEST_COST = 1;

    /** 合成 1 个<i>染色</i>潜影盒需要的染料数量（原版配方：染色盒 = 潜影盒 + 1 染料） */
    public static final int DYE_COST = 1;

    private VoidWarehouseShulker() {
    }

    /**
     * 这个堆叠是不是一个潜影盒（任何颜色都算）。
     *
     * <p>26.3 没有 {@code ShulkerBoxItem}，潜影盒就是方块 {@link ShulkerBoxBlock} 的
     * {@link BlockItem}，所以从方块那一侧反查最省事，也顺手覆盖了 16 种染色盒。</p>
     */
    public static boolean isShulkerBox(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        return stack.getItem() instanceof BlockItem blockItem
                && blockItem.getBlock() instanceof ShulkerBoxBlock;
    }

    /**
     * 这个盒子的颜色；<b>无色盒返回 {@code null}</b>。
     *
     * <p>颜色记在<b>方块</b>上（{@link ShulkerBoxBlock#getColor()}），物品只是个
     * {@code BlockItem}，所以要从方块反查。</p>
     */
    public static DyeColor colorOf(ItemStack box) {
        if (box == null || box.isEmpty()) {
            return null;
        }
        return box.getItem() instanceof BlockItem blockItem
                && blockItem.getBlock() instanceof ShulkerBoxBlock shulker
                ? shulker.getColor() : null;
    }

    /**
     * 拆解这个盒子时应当<b>归还的染料</b>（无色盒返回 {@link ItemStack#EMPTY}）。
     *
     * <p>原版配方是「任意潜影盒 + 1 个对应染料 → 染色盒」，所以拆染色盒时除了
     * {@code 2 壳 + 1 箱} 还得把那个染料吐回来。少了这一步，玩家每存一次染色盒就
     * 平白少一个染料 —— 而仓库对外承诺的是「拆开 = 逆向合成、严格守恒」。</p>
     *
     * <p>26.3 里 16 种染料收在一个 {@code ColorCollection}（{@code Items.DYE}）里，
     * 用 {@code pick(DyeColor)} 取色，不必枚举 16 个常量。</p>
     */
    public static ItemStack dyeOf(ItemStack box) {
        DyeColor color = colorOf(box);
        return color == null ? ItemStack.EMPTY : new ItemStack(Items.DYE.pick(color), DYE_COST);
    }

    /** 一盒装满能装多少个「这种物品」 */
    public static int capacity(ItemStack template) {
        return BOX_SLOTS * Math.max(1, template.getMaxStackSize());
    }

    /**
     * 读出盒子里所有<b>非空</b>的内容。
     *
     * <p>返回的每一份都是<b>拷贝</b>（{@code nonEmptyItemCopyStream}），
     * 调用方可以放心地清空它们，不会反过来改到盒子本身。</p>
     */
    public static List<ItemStack> contentsOf(ItemStack box) {
        if (!isShulkerBox(box)) {
            return List.of();
        }
        ItemContainerContents contents = box.get(DataComponents.CONTAINER);
        if (contents == null) {
            return List.of();
        }
        List<ItemStack> out = new ArrayList<>();
        contents.nonEmptyItemCopyStream().forEach(out::add);
        return out;
    }

    /** 空盒子？（盒子里一个东西都没有） */
    public static boolean isEmptyBox(ItemStack box) {
        return isShulkerBox(box) && contentsOf(box).isEmpty();
    }

    /**
     * 这种物品能不能「装进盒子」。
     *
     * <p><b>潜影盒不行</b> —— 原版是靠 {@code ShulkerBoxBlock#canFitInsideContainerItems}
     * 在放进去那一刻挡住的（{@code minecraft:shulker_boxes} 物品标签），而 {@link #pack}
     * 是直接 {@code set(CONTAINER, ...)} 造盒子，<b>绕过</b>了那道检查。于是「盒模式点
     * 潜影盒那一格」就会造出原版根本不允许存在的「盒子套盒子」。</p>
     *
     * <p>那个嵌套盒送回仓库时会被 {@code unpackShulkerBox} 拆成「里层盒子 + 2 壳 + 1 箱」，
     * 而外盒的材料账是拿<b>同一个空盒格</b>算的（{@code planBoxMaterials}）——
     * 取货那一步先把这一格取空，扣材料时便再也扣不到，外盒等于白送。
     * 一来一回，每循环一次就凭空多出一个盒子的价值（2026-11 真踩到）。
     * 所以「目标格本身是潜影盒」时<b>一律不装盒</b>，直接按散盒交出，见两个取货口。</p>
     */
    public static boolean isBoxable(ItemStack template) {
        return template != null && !template.isEmpty() && !isShulkerBox(template);
    }

    /**
     * 这种物品本身是不是<b>做盒子的材料</b>（潜影壳 / 箱子）。
     *
     * <h2>为什么这两样的材料账要单独算</h2>
     * <p>装盒的材料账（{@link VoidWarehouseData#planBoxMaterials}）是从<b>仓库</b>扣
     * {@link #SHELL_COST} 壳 + {@link #CHEST_COST} 箱，而两个取货口都是
     * <b>先把货取走、再扣材料</b>（顺序不能反：扣材料会移除别的格子、让下标前移）。</p>
     *
     * <p>于是「目标格本身就是潜影壳 / 箱子」时出现了<b>材料与货共源</b>：取走整整一盒容量
     * （潜影壳 1728 个）之后，仓库里那 {@code 2} 个壳恰好归零，
     * {@code consumeBoxMaterials} 再也扣不到 —— 它只会留一条 WARN，而这盒子是实打实
     * 交到玩家手上的。算一笔账：仓库 1728 壳 + 1 箱、0 空盒，盒模式点壳那一格 → 拿到
     * 「装着 1728 壳的盒子」，送回仓库变回 1728 壳 + <b>1 个空盒</b>。净效果 =
     * <b>1 个箱子（8 木板）换 1 个潜影盒</b>，可无限循环；而原版要 2 壳 + 1 箱。</p>
     *
     * <p>所以取这两样时，材料账必须先<b>把「马上要离库的那批货」刨掉</b>（{@link VoidWarehouseData#hasBoxMaterials(BoxMaterials, ItemStack, BigInteger)}
     * 与 {@link VoidWarehouseData#maxBoxesUpTo(long, ItemStack)}）—— 盒子照给，但成本只能从那批货<b>之外</b>的库存里出。
     * {@link #pack} 绕过了原版 {@code canFitInsideContainerItems}，凡是能当材料的东西都得自己把账算清楚。</p>
     */
    public static boolean isBoxPart(ItemStack template) {
        if (template == null || template.isEmpty()) {
            return false;
        }
        return template.is(Items.SHULKER_SHELL) || template.is(Items.CHEST);
    }

    /**
     * 把 {@code count} 个 {@code template} 打包成一个潜影盒。
     *
     * <p>从第 0 格开始按「每格装满」往后铺，装不下的部分留在下一格（原版潜影盒
     * 本来就允许有空位），所以 {@code count} 小于一盒容量时得到的就是一个「没装满的盒子」。</p>
     *
     * <p>{@code template} 只当样板用（数量无所谓），内部一律走
     * {@code copyWithCount(n)} 造新堆叠，<b>绝不把同一个实例挂在两处</b>。</p>
     *
     * <p>⚠️ <b>调用前必须先问 {@link #isBoxable}</b>：这个方法不做类型检查，
     * 拿潜影盒当模板会造出原版不允许的嵌套盒（后果见 {@link #isBoxable}）。</p>
     */
    public static ItemStack pack(ItemStack template, long count) {
        int max = Math.max(1, template.getMaxStackSize());
        List<ItemStack> slots = new ArrayList<>(BOX_SLOTS);
        long remaining = Math.max(0L, count);
        while (remaining > 0 && slots.size() < BOX_SLOTS) {
            int n = (int) Math.min(max, remaining);
            slots.add(template.copyWithCount(n));
            remaining -= n;
        }
        ItemStack box = new ItemStack(Items.SHULKER_BOX);
        if (!slots.isEmpty()) {
            // fromItems 会把内容压到前面（vanilla 的潜影盒本来就只存「非空的那几格」）。
            // 一个都没装时不写组件，交出一个真正「干净」的空盒子。
            box.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(slots));
        }
        return box;
    }
}
